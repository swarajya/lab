const MOCK = {
  user: {
    name: "Alex Rivera",
    role: "Audio Engineer",
    email: "alex.rivera@studio.example",
    org: "Audio Studio",
    initials: "AR",
    timezone: "UTC",
  },

  kpis: [
    { key: "projects", label: "Total Projects", value: "28", delta: "+3 this week", tone: "neutral" },
    { key: "audio", label: "Generated Audio", value: "1,842", delta: "+126 today", tone: "good" },
    { key: "chars", label: "Characters Processed", value: "14.6M", delta: "62% of quota", tone: "neutral" },
    { key: "reviews", label: "Pending Reviews", value: "17", delta: "4 urgent", tone: "warn" },
    { key: "similarity", label: "Average Similarity", value: "91.4%", delta: "+1.2 pts", tone: "good" },
    { key: "approval", label: "Approval Rate", value: "86%", delta: "last 30 days", tone: "good" },
    { key: "failed", label: "Failed Jobs", value: "9", delta: "0.7% of runs", tone: "bad" },
  ],

  activity: [
    { time: "2m ago", user: "Maya Kapoor", action: "Approved generation", target: "AUR-1842 · Product walkthrough" },
    { time: "18m ago", user: "Alex Rivera", action: "Started training", target: "Brand Voice v3 · Custom TTS" },
    { time: "41m ago", user: "System", action: "Job completed", target: "JOB-9041 · XTTS v2" },
    { time: "1h ago", user: "Rohan Mehta", action: "Requested regeneration", target: "HIN-332 · Support greeting" },
    { time: "2h ago", user: "Elena Voss", action: "Uploaded voice sample", target: "Elena Neutral · 00:42" },
    { time: "4h ago", user: "Alex Rivera", action: "Created project", target: "Podcast Intro Series" },
  ],

  projects: [
    { id: "prj-aurora", name: "Aurora Narration Pack", client: "ClearHost", clips: 214, chars: "1.2M", lang: "EN", status: "Active", updated: "12 min ago", hue: 32 },
    { id: "prj-support", name: "Customer Support Voice", client: "Brahma Care", clips: 86, chars: "340K", lang: "EN / HI", status: "In review", updated: "1 hr ago", hue: 168 },
    { id: "prj-hindi", name: "Hindi Product Demo", client: "VisionCloud", clips: 41, chars: "98K", lang: "HI", status: "Active", updated: "3 hr ago", hue: 198 },
    { id: "prj-podcast", name: "Podcast Intro Series", client: "Internal", clips: 12, chars: "24K", lang: "EN", status: "Draft", updated: "Yesterday", hue: 280 },
    { id: "prj-onboard", name: "Onboarding Tutorials", client: "ClearAI", clips: 63, chars: "410K", lang: "EN", status: "Active", updated: "Tue", hue: 48 },
    { id: "prj-brand", name: "Brand Voice v3", client: "Brahma", clips: 9, chars: "18K", lang: "EN", status: "Training", updated: "Mon", hue: 12 },
  ],

  voices: [
    { id: "v-aria", code: "spk-001", name: "Aria Sterling", speaker: "Aria S.", lang: "English (US)", gender: "Female", duration: "0:42", file: "aria_sterling.wav", embedding: "emb-9f2a71", updated: "2026-08-14 09:15", status: "Ready", quality: 96, similarity: 94, tags: ["Narration", "Warm", "Studio"], accent: "General American" },
    { id: "v-rohan", code: "spk-002", name: "Rohan Mehta", speaker: "Rohan M.", lang: "Hindi", gender: "Male", duration: "1:05", file: "rohan_mehta.wav", embedding: "emb-41bc08", updated: "2026-08-18 14:33", status: "Ready", quality: 93, similarity: 91, tags: ["Support", "Clear", "Neutral"], accent: "Indian" },
    { id: "v-elena", code: "spk-003", name: "Elena Voss", speaker: "Elena V.", lang: "German", gender: "Female", duration: "0:37", file: "elena_voss.wav", embedding: "emb-77d0e2", updated: "2026-08-22 16:48", status: "Ready", quality: 91, similarity: 89, tags: ["Documentary", "Low"], accent: "Standard German" },
    { id: "v-kenji", code: "spk-004", name: "Kenji Sato", speaker: "Kenji S.", lang: "Japanese", gender: "Male", duration: "0:58", file: "kenji_voice.wav", embedding: "—", updated: "2026-08-29 11:02", status: "Processing", quality: 88, similarity: 86, tags: ["Product", "Bright"], accent: "Tokyo" },
    { id: "v-maya", code: "spk-005", name: "Maya Chen", speaker: "Maya C.", lang: "English (UK)", gender: "Female", duration: "1:12", file: "maya_chen.wav", embedding: "emb-12aa90", updated: "2026-08-19 10:04", status: "Ready", quality: 95, similarity: 93, tags: ["Tutorial", "Crisp"], accent: "Received Pronunciation" },
    { id: "v-diego", code: "spk-006", name: "Diego Alvarez", speaker: "Diego A.", lang: "Spanish", gender: "Male", duration: "0:44", file: "diego_alvarez.wav", embedding: "emb-55c1d4", updated: "2026-08-21 13:20", status: "Ready", quality: 90, similarity: 88, tags: ["Ads", "Energetic"], accent: "LatAm" },
    { id: "v-noura", code: "spk-007", name: "Noura Al-Fayed", speaker: "Noura A.", lang: "Arabic", gender: "Female", duration: "0:31", file: "noura_ref.mp3", embedding: "emb-08e3bb", updated: "2026-08-16 08:11", status: "Ready", quality: 87, similarity: 85, tags: ["News", "Formal"], accent: "MSA" },
    { id: "v-brand", code: "spk-008", name: "Brahma Brand", speaker: "Composite", lang: "English (IN)", gender: "Neutral", duration: "0:21", file: "brahma_brand.mp3", embedding: "—", updated: "2026-08-25 08:22", status: "Failed", quality: 82, similarity: 79, tags: ["Brand", "Training"], accent: "Indian English" },
  ],

  datasets: [
    { id: "ds-brand", name: "Brand Voice v3 Corpus", files: 428, duration: "6h 12m", quality: 91, status: "Processing", progress: 64, model: "Custom TTS", updated: "18 min ago" },
    { id: "ds-aria", name: "Aria Studio Sessions", files: 186, duration: "2h 41m", quality: 97, status: "Completed", progress: 100, model: "XTTS v2", updated: "Yesterday" },
    { id: "ds-support", name: "Support Call Cleaned", files: 902, duration: "11h 04m", quality: 84, status: "Completed", progress: 100, model: "External TTS", updated: "3 days ago" },
    { id: "ds-hindi", name: "Hindi Demo Takes", files: 74, duration: "48m", quality: 88, status: "Failed", progress: 37, model: "Piper", updated: "Mon", error: "Alignment failed on 11 clips" },
    { id: "ds-podcast", name: "Podcast Room Tone + VO", files: 33, duration: "22m", quality: 79, status: "Processing", progress: 21, model: "Custom TTS", updated: "Just now" },
  ],

  audio: [
    { id: "AUR-1842", project: "Aurora Narration Pack", script: "Welcome to Aurora. In the next two minutes we will walk through how your workspace stays in sync…", voice: "Aria Sterling", model: "XTTS v2", duration: "0:18", similarity: 94, quality: 93, status: "Approved", created: "Today, 12:04", chars: 412 },
    { id: "SUP-771", project: "Customer Support Voice", script: "Thanks for waiting. I can help you reset your workspace access in just a few steps.", voice: "Rohan Mehta", model: "External TTS", duration: "0:09", similarity: 91, quality: 90, status: "In review", created: "Today, 11:41", chars: 98 },
    { id: "HIN-332", project: "Hindi Product Demo", script: "Namaste. VisionCloud aapke data ko ek jagah laata hai, taaki aap decisions jaldi le saken.", voice: "Rohan Mehta", model: "XTTS v2", duration: "0:12", similarity: 86, quality: 84, status: "Regenerate", created: "Today, 10:18", chars: 104 },
    { id: "ONB-119", project: "Onboarding Tutorials", script: "Open the left rail and choose Generate Audio. Paste your script, then pick a voice and model.", voice: "Maya Chen", model: "Piper", duration: "0:14", similarity: 92, quality: 91, status: "Approved", created: "Yesterday", chars: 118 },
    { id: "POD-044", project: "Podcast Intro Series", script: "From the studio floor — this is Signal Path, stories from people who ship voice systems.", voice: "Aria Sterling", model: "Custom TTS", duration: "0:08", similarity: 78, quality: 80, status: "Draft", created: "Yesterday", chars: 92 },
    { id: "AUR-1839", project: "Aurora Narration Pack", script: "If a clip fails evaluation, it returns to the queue with the reviewer note attached.", voice: "Aria Sterling", model: "XTTS v2", duration: "0:11", similarity: 95, quality: 94, status: "Approved", created: "Tue", chars: 96 },
    { id: "SUP-760", project: "Customer Support Voice", script: "I am sorry about the delay. Let me check the latest job status for your account.", voice: "Rohan Mehta", model: "External TTS", duration: "0:07", similarity: 89, quality: 88, status: "Rejected", created: "Tue", chars: 86 },
    { id: "BRD-012", project: "Brand Voice v3", script: "Brahma builds the operating system for modern infrastructure teams.", voice: "Brahma Brand", model: "Custom TTS", duration: "0:06", similarity: 81, quality: 79, status: "In review", created: "Mon", chars: 68 },
  ],

  reviews: [
    {
      id: "AUR-1842",
      project: "Aurora Narration Pack",
      script: "Welcome to Aurora. In the next two minutes we will walk through how your workspace stays in sync across every device, without asking your team to change how they already work.",
      reference: { voice: "Aria Sterling", lang: "English (US)", duration: "0:17", take: "Studio take 14" },
      generated: { voice: "Aria Sterling", model: "XTTS v2", duration: "0:18", job: "JOB-9041" },
      scores: { similarity: 92, naturalness: 89, pronunciation: 96, prosody: 87, overall: 91 },
      feedback: "Closely matches Aria’s chest resonance and pacing. Slight lift on “workspace” feels a touch brighter than the reference. Terminal fall-off is clean.",
      recommendation: "Approve for the Aurora pack. Optional: regenerate with stability 0.72 if you want a warmer landing on the last clause.",
    },
  ],

  jobs: [
    { id: "JOB-9048", project: "Aurora Narration Pack", stage: "Queued", progress: 0, model: "XTTS v2", voice: "Aria Sterling", time: "—", error: "—", started: "13:18" },
    { id: "JOB-9047", project: "Hindi Product Demo", stage: "Processing", progress: 46, model: "XTTS v2", voice: "Rohan Mehta", time: "00:41", error: "—", started: "13:16" },
    { id: "JOB-9046", project: "Customer Support Voice", stage: "Evaluating", progress: 78, model: "External TTS", voice: "Rohan Mehta", time: "01:12", error: "—", started: "13:12" },
    { id: "JOB-9045", project: "Onboarding Tutorials", stage: "Review", progress: 100, model: "Piper", voice: "Maya Chen", time: "00:38", error: "—", started: "12:54" },
    { id: "JOB-9041", project: "Aurora Narration Pack", stage: "Approved", progress: 100, model: "XTTS v2", voice: "Aria Sterling", time: "00:52", error: "—", started: "12:01" },
    { id: "JOB-9033", project: "Brand Voice v3", stage: "Processing", progress: 22, model: "Custom TTS", voice: "Brahma Brand", time: "04:18", error: "—", started: "09:40" },
    { id: "JOB-9028", project: "Hindi Product Demo", stage: "Failed", progress: 37, model: "Piper", voice: "Rohan Mehta", time: "00:19", error: "Phoneme align timeout", started: "Yesterday" },
    { id: "JOB-9021", project: "Podcast Intro Series", stage: "Approved", progress: 100, model: "Custom TTS", voice: "Aria Sterling", time: "01:04", error: "—", started: "Yesterday" },
  ],

  models: [
    {
      id: "mdl-ext",
      name: "External TTS",
      type: "External",
      provider: "Studio Cloud",
      version: "2025.8.1",
      languages: ["EN", "HI", "ES", "DE", "JA", "AR"],
      status: "Healthy",
      endpoint: "https://tts.studio.internal/v1/external",
      compute: "Managed GPU",
      latency: "420 ms",
      config: { style_exaggeration: 0.35, speaker_boost: true, output: "48kHz pcm" },
    },
    {
      id: "mdl-xtts",
      name: "XTTS v2",
      type: "Local",
      provider: "Coqui (self-hosted)",
      version: "2.0.3",
      languages: ["EN", "HI", "ES", "DE", "FR", "PT"],
      status: "Healthy",
      endpoint: "http://xtts.voice.svc:5002/tts",
      compute: "A10G × 2",
      latency: "1.1 s",
      config: { temperature: 0.65, top_p: 0.85, repetition_penalty: 2.0 },
    },
    {
      id: "mdl-piper",
      name: "Piper",
      type: "Local",
      provider: "rhasspy/piper",
      version: "1.2.0",
      languages: ["EN", "HI", "DE"],
      status: "Degraded",
      endpoint: "http://piper.voice.svc:10200/api",
      compute: "CPU · 16 vCPU",
      latency: "180 ms",
      config: { noise_scale: 0.333, length_scale: 1.0, noise_w: 0.333 },
    },
    {
      id: "mdl-custom",
      name: "Custom TTS",
      type: "Local",
      provider: "Brahma Voice Labs",
      version: "brand-v3.4",
      languages: ["EN", "HI"],
      status: "Training",
      endpoint: "http://custom-tts.voice.svc:8088/infer",
      compute: "H100 × 1",
      latency: "—",
      config: { checkpoint: "epoch-18", cfg_scale: 1.4, sample_rate: 44100 },
    },
  ],

  logs: [
    { user: "Alex Rivera", action: "Generated audio", project: "Aurora Narration Pack", target: "AUR-1842", time: "Today 12:04", status: "Success" },
    { user: "Maya Kapoor", action: "Approved clip", project: "Aurora Narration Pack", target: "AUR-1842", time: "Today 12:11", status: "Success" },
    { user: "System", action: "Evaluation complete", project: "Customer Support Voice", target: "JOB-9046", time: "Today 13:14", status: "Success" },
    { user: "Rohan Mehta", action: "Rejected clip", project: "Customer Support Voice", target: "SUP-760", time: "Tue 16:22", status: "Success" },
    { user: "Elena Voss", action: "Uploaded sample", project: "—", target: "Elena Neutral", time: "Tue 14:03", status: "Success" },
    { user: "Alex Rivera", action: "Updated model config", project: "—", target: "XTTS v2", time: "Tue 11:40", status: "Success" },
    { user: "System", action: "Training step failed", project: "Hindi Product Demo", target: "ds-hindi", time: "Mon 19:12", status: "Failed" },
    { user: "Alex Rivera", action: "Created project", project: "Podcast Intro Series", target: "prj-podcast", time: "Mon 09:08", status: "Success" },
    { user: "Maya Kapoor", action: "Exported stems", project: "Onboarding Tutorials", target: "ONB-119", time: "Sun 18:44", status: "Success" },
    { user: "System", action: "Quota warning", project: "—", target: "org-quota", time: "Sun 08:00", status: "Warning" },
  ],

  analytics: {
    generated: [42, 58, 61, 49, 77, 84, 91, 73, 88, 96, 104, 126],
    months: ["Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"],
    models: [
      { name: "XTTS v2", pct: 41, color: "var(--accent)" },
      { name: "External TTS", pct: 33, color: "var(--good)" },
      { name: "Piper", pct: 16, color: "var(--info)" },
      { name: "Custom TTS", pct: 10, color: "var(--warn)" },
    ],
    voices: [
      { name: "Aria Sterling", n: 612 },
      { name: "Rohan Mehta", n: 401 },
      { name: "Maya Chen", n: 288 },
      { name: "Elena Voss", n: 194 },
      { name: "Diego Alvarez", n: 162 },
    ],
  },

  defaultScript:
    "Welcome to Aurora. In the next two minutes we will walk through how your workspace stays in sync across every device, without asking your team to change how they already work.",

  modelParams: {
    "External TTS": [
      { key: "style", label: "Style exaggeration", min: 0, max: 1, step: 0.01, value: 0.35 },
      { key: "boost", label: "Speaker boost", type: "toggle", value: true },
    ],
    "XTTS v2": [
      { key: "temp", label: "Temperature", min: 0.1, max: 1.2, step: 0.05, value: 0.65 },
      { key: "topp", label: "Top-p", min: 0.5, max: 1, step: 0.01, value: 0.85 },
      { key: "rep", label: "Repetition penalty", min: 1, max: 4, step: 0.1, value: 2.0 },
    ],
    Piper: [
      { key: "noise", label: "Noise scale", min: 0, max: 1, step: 0.01, value: 0.33 },
      { key: "length", label: "Length scale", min: 0.5, max: 1.5, step: 0.05, value: 1.0 },
    ],
    "Custom TTS": [
      { key: "cfg", label: "CFG scale", min: 0.5, max: 3, step: 0.1, value: 1.4 },
      { key: "ckpt", label: "Checkpoint", type: "select", options: ["epoch-12", "epoch-18", "epoch-24"], value: "epoch-18" },
    ],
  },
};
