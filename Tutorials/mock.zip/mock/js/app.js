const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const state = {
  view: "dashboard",
  theme: localStorage.getItem("as-theme") || "dark",
  collapsed: localStorage.getItem("as-collapsed") === "1",
  script: MOCK.defaultScript,
  project: MOCK.projects[0].id,
  voice: MOCK.voices[0].id,
  model: "XTTS v2",
  language: "English (US)",
  speaker: "Aria S.",
  emotion: "Warm narration",
  speed: 1,
  pitch: 0,
  volume: 0.85,
  stability: 0.68,
  similarity: 0.82,
  generated: false,
  generating: false,
  play: {},
  audioQuery: "",
  audioStatus: "All",
  audioVoice: "All",
  reviewId: "AUR-1842",
  settingsTab: "profile",
  comment: "",
  advancedOpen: false,
  audioSort: "created",
  audioSortDir: "desc",
};

document.documentElement.dataset.theme = state.theme;
const isMobile = () => window.matchMedia("(max-width: 860px)").matches;
if (isMobile()) state.collapsed = true;
if (state.collapsed) $(".app").classList.add("is-collapsed");
$("#userEmail").textContent = MOCK.user.email;
$("#userChip").textContent = MOCK.user.initials;

function toast(message) {
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = message;
  $("#toasts").appendChild(el);
  setTimeout(() => el.remove(), 2800);
}

function closeMobileNav() {
  $(".app").classList.remove("is-nav-open");
  if (!isMobile()) return;
  state.collapsed = true;
  $(".app").classList.add("is-collapsed");
  if ($("#drawer").hidden && $("#modal").hidden && $("#palette").hidden) {
    $("#overlay").hidden = true;
  }
}

function closeLayers() {
  $("#overlay").hidden = true;
  $("#drawer").hidden = true;
  $("#modal").hidden = true;
  $("#palette").hidden = true;
  closeMobileNav();
}

function openDrawer(html) {
  $("#drawer").innerHTML = html;
  $("#drawer").hidden = false;
  $("#overlay").hidden = false;
}

function openModal(html) {
  $("#modal").innerHTML = html;
  $("#modal").hidden = false;
  $("#overlay").hidden = false;
}

function badge(status) {
  const cls = String(status).replace(/\s+/g, "-");
  return `<span class="badge badge-${cls}">${status}</span>`;
}

function words(text) {
  const t = text.trim();
  return t ? t.split(/\s+/).length : 0;
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function iconPlay() {
  return `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>`;
}
function iconPause() {
  return `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 5h3v14H7zM14 5h3v14h-3z"/></svg>`;
}
function iconReview() {
  return lucide(`<path d="m18 16 4-4-4-4"/><path d="m6 8-4 4 4 4"/><path d="m14.5 4-5 16"/>`);
}
function iconExport() {
  return lucide(`<path d="M12 3v12"/><path d="m8 11 4 4 4-4"/><path d="M5 19h14"/>`);
}
function sortMark(key) {
  if (state.audioSort !== key) return "";
  return state.audioSortDir === "asc" ? " ↑" : " ↓";
}
function lucide(d) {
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
}
function kpiIcon(key) {
  const map = {
    projects: `<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>`,
    audio: `<path d="M2 10v3"/><path d="M6 6v11"/><path d="M10 3v18"/><path d="M14 8v7"/><path d="M18 5v13"/><path d="M22 10v3"/>`,
    chars: `<path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/>`,
    reviews: `<path d="m18 16 4-4-4-4"/><path d="m6 8-4 4 4 4"/><path d="m14.5 4-5 16"/>`,
    similarity: `<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/>`,
    approval: `<path d="M21.801 10A10 10 0 1 1 17 3.335"/><path d="m9 11 3 3L22 4"/>`,
    failed: `<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/>`,
  };
  return lucide(map[key] || map.audio);
}

/* ---------- views ---------- */

function viewDashboard() {
  const jobs = MOCK.jobs;
  const counts = {
    Queued: jobs.filter((j) => j.stage === "Queued").length,
    Processing: jobs.filter((j) => j.stage === "Processing").length,
    Evaluating: jobs.filter((j) => j.stage === "Evaluating").length,
    Review: jobs.filter((j) => j.stage === "Review").length,
    Approved: jobs.filter((j) => j.stage === "Approved").length,
  };

  return `
    <div class="page">
      <div class="page-head">
        <div class="row">
          <button class="btn btn-ghost" data-go="jobs">View jobs</button>
          <button class="btn btn-primary" data-go="generate">Generate audio</button>
        </div>
      </div>

      <div class="kpi-grid">
        ${MOCK.kpis
          .map(
            (k) => `
          <article class="card kpi tone-${k.tone}">
            <span class="kpi-icon">${kpiIcon(k.key)}</span>
            <div class="label">${k.label}</div>
            <div class="value">${k.value}</div>
            <div class="delta">${k.delta}</div>
          </article>`
          )
          .join("")}
      </div>

      <div class="grid-2">
        <section class="card">
          <div class="section-title">Recent generations <button class="link" data-go="audio">View all</button></div>
          <div class="table-wrap">
            <table>
              <thead><tr><th>Clip</th><th>Project</th><th>Voice</th><th>Model</th><th>Similarity</th><th>Status</th></tr></thead>
              <tbody>
                ${MOCK.audio
                  .slice(0, 6)
                  .map(
                    (a) => `
                  <tr class="is-click" data-go="audio">
                    <td class="mono">${a.id}</td>
                    <td>${a.project}</td>
                    <td>${a.voice}</td>
                    <td>${a.model}</td>
                    <td class="mono">${a.similarity}%</td>
                    <td>${badge(a.status)}</td>
                  </tr>`
                  )
                  .join("")}
              </tbody>
            </table>
          </div>
        </section>

        <section class="card">
          <div class="section-title">Activity</div>
          <ul class="timeline">
            ${MOCK.activity
              .map(
                (e) => `
              <li>
                <time>${e.time}</time>
                <div><strong>${esc(e.action)}</strong><em>${esc(e.user)} · ${esc(e.target)}</em></div>
              </li>`
              )
              .join("")}
          </ul>
        </section>
      </div>

      <section class="card" style="margin-top:12px">
        <div class="section-title">Job status <button class="link" data-go="jobs">Open pipeline</button></div>
        <div class="job-pillars">
          ${Object.entries(counts)
            .map(([k, v]) => `<div class="pillar"><b>${v}</b><span>${k}</span></div>`)
            .join("")}
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Job</th><th>Stage</th><th>Progress</th><th>Model</th><th>Voice</th></tr></thead>
            <tbody>
              ${jobs
                .slice(0, 5)
                .map(
                  (j) => `
                <tr class="is-click" data-go="jobs">
                  <td class="mono">${j.id}</td>
                  <td>${badge(j.stage)}</td>
                  <td><div class="progress"><span style="width:${j.progress}%"></span></div></td>
                  <td>${j.model}</td>
                  <td>${j.voice}</td>
                </tr>`
                )
                .join("")}
            </tbody>
          </table>
        </div>
      </section>
    </div>`;
}

function viewProjects() {
  return `
    <div class="page">
      <div class="page-head">
        <button class="btn btn-primary" data-action="new-project">New project</button>
      </div>
      <div class="grid-auto">
        ${MOCK.projects
          .map(
            (p) => `
          <article class="card project-card">
            <div class="project-cover" style="background:hsl(${p.hue} 22% 20%)">
              ${badge(p.status)}
            </div>
            <div class="body">
              <h3>${p.name}</h3>
              <p class="muted">${p.client} · ${p.lang}</p>
              <p class="muted" style="margin-top:10px">${p.clips} clips · ${p.chars} chars · Updated ${p.updated}</p>
              <div class="row" style="margin-top:12px">
                <button class="btn btn-primary btn-compact" data-go="generate" data-project="${p.id}">Generate</button>
                <button class="btn btn-ghost btn-compact" data-action="open-project" data-id="${p.id}">Open</button>
              </div>
            </div>
          </article>`
          )
          .join("")}
      </div>
    </div>`;
}

function viewGenerate() {
  const voices = MOCK.voices.map((v) => `<option value="${v.id}" ${v.id === state.voice ? "selected" : ""}>${v.name} — ${v.lang}</option>`).join("");
  const projects = MOCK.projects.map((p) => `<option value="${p.id}" ${p.id === state.project ? "selected" : ""}>${p.name}</option>`).join("");
  const models = ["External TTS", "XTTS v2", "Piper", "Custom TTS"]
    .map((m) => `<option ${m === state.model ? "selected" : ""}>${m}</option>`)
    .join("");
  const params = MOCK.modelParams[state.model] || [];

  return `
    <div class="page">
      <div class="page-head">
        <div class="row">
          <span class="chip">${MOCK.projects.find((p) => p.id === state.project)?.name}</span>
          <span class="chip">${state.model}</span>
        </div>
      </div>

      <div class="gen-layout">
        <div>
        <section class="card editor-card">
          <div class="editor-toolbar">
            <strong>Script</strong>
            <span>Plain text · max 5,000 characters</span>
          </div>
          <textarea id="script">${esc(state.script)}</textarea>
          <div class="editor-foot">
            <span id="scriptStats">${state.script.length} characters · ${words(state.script)} words · ~${Math.max(1, Math.round(words(state.script) / 2.4))}s spoken</span>
            <button class="btn btn-ghost btn-compact" data-action="sample-script">Insert sample</button>
          </div>
        </section>

        <section class="card preview" id="previewCard">
        <div class="section-title" style="padding:0 0 10px">${state.generated ? "Generated preview" : "Preview"}</div>
        ${
          state.generated
            ? `
        <div class="wave-wrap"><canvas id="genWave" data-wave="preview-gen"></canvas></div>
        <div class="player">
          <button class="play" data-action="toggle-play" data-key="preview-gen" data-tip="Play preview">${iconPlay()}</button>
          <div>
            <strong id="playTime">0:00</strong>
            <span class="muted"> / 0:18</span>
          </div>
          <div class="meta-chips" style="margin:0;flex:1">
            <span class="chip">${state.model}</span>
            <span class="chip">${MOCK.voices.find((v) => v.id === state.voice)?.name}</span>
            <span class="chip">${state.emotion}</span>
            <span class="chip">Speed ${state.speed}</span>
          </div>
        </div>
        <div class="row" style="margin-top:12px">
          <button class="btn btn-ghost" data-action="generate">Regenerate</button>
          <button class="btn" data-action="save-clip">Save</button>
          <button class="btn btn-primary" data-action="send-review">Send to review</button>
        </div>`
            : `
        <div class="empty" style="padding:20px 8px">
          <strong>No take yet</strong>
          Configure voice and model, then generate a preview.
        </div>`
        }
        </section>
        </div>

        <aside class="card gen-side">
        <div class="gen-side-scroll">
          <div class="field-group">
            <h4>Voice &amp; model</h4>
            <div class="field">
              <label>Project</label>
              <select id="selProject">${projects}</select>
            </div>
            <div class="field">
              <label>Voice</label>
              <select id="selVoice">${voices}</select>
            </div>
            <div class="field">
              <label>TTS model</label>
              <select id="selModel">${models}</select>
            </div>
          </div>
          <div class="field-group">
            <h4>Delivery</h4>
            <div class="field-grid">
              <div class="field">
                <label>Language</label>
                <select id="selLang">
                  ${["English (US)", "English (UK)", "English (IN)", "Hindi", "German", "Japanese", "Spanish", "Arabic"]
                    .map((l) => `<option ${l === state.language ? "selected" : ""}>${l}</option>`)
                    .join("")}
                </select>
              </div>
              <div class="field">
                <label>Speaker</label>
                <select id="selSpeaker">
                  ${MOCK.voices.map((v) => `<option ${v.speaker === state.speaker ? "selected" : ""}>${v.speaker}</option>`).join("")}
                </select>
              </div>
            </div>
            <div class="field">
              <label>Emotion / style</label>
              <select id="selEmotion">
                ${["Warm narration", "Neutral", "Conversational", "Urgent", "Soft", "Broadcast"]
                  .map((e) => `<option ${e === state.emotion ? "selected" : ""}>${e}</option>`)
                  .join("")}
              </select>
            </div>
          </div>
          <div class="field-group">
            <h4>Performance</h4>
            ${slider("speed", "Speed", state.speed, 0.7, 1.4, 0.05)}
            ${slider("pitch", "Pitch", state.pitch, -6, 6, 0.5)}
            ${slider("volume", "Volume", state.volume, 0.2, 1, 0.05)}
          </div>
          <div class="field-group">
            <h4>Voice match</h4>
            ${slider("stability", "Stability", state.stability, 0, 1, 0.01)}
            ${slider("similarity", "Similarity", state.similarity, 0, 1, 0.01)}
          </div>
          <details class="adv" id="advParams" ${state.advancedOpen ? "open" : ""}>
            <summary>Advanced model parameters</summary>
            <div class="adv-body" id="modelParams">${renderParams(params)}</div>
          </details>
        </div>
          <div class="gen-side-cta">
            <button class="btn btn-primary btn-lg ${state.generating ? "is-loading" : ""}" ${state.generating ? "disabled" : ""} data-action="generate">
              ${state.generating ? "Rendering" : "Generate audio"}
            </button>
          </div>
        </aside>
      </div>
    </div>`;
}

function slider(key, label, value, min, max, step) {
  return `
    <div class="slider">
      <label>${label}</label>
      <output data-out="${key}">${value}</output>
      <input type="range" data-range="${key}" min="${min}" max="${max}" step="${step}" value="${value}" />
    </div>`;
}

function renderParams(params) {
  return params
    .map((p) => {
      if (p.type === "toggle") {
        return `<label class="row" style="margin-bottom:12px;font-size:13px"><input type="checkbox" ${p.value ? "checked" : ""} /> ${p.label}</label>`;
      }
      if (p.type === "select") {
        return `<div class="field"><label>${p.label}</label><select>${p.options
          .map((o) => `<option ${o === p.value ? "selected" : ""}>${o}</option>`)
          .join("")}</select></div>`;
      }
      return slider(p.key, p.label, p.value, p.min, p.max, p.step);
    })
    .join("");
}

function viewVoices() {
  const langs = ["English", "Hindi", "Bengali", "Tamil", "Telugu", "Marathi", "Spanish", "French", "German", "Japanese"];
  const plus = lucide(`<path d="M5 12h14"/><path d="M12 5v14"/>`);
  const mic = lucide(`<path d="m11 7.601-5.994 8.19a1 1 0 0 0 .1 1.298l.817.818a1 1 0 0 0 1.314.087L15.09 12"/><path d="M16.5 21.174C15.5 20.5 14.372 20 13 20c-2.058 0-3.928 2.356-6 2-2.072-.356-2.775-3.369-1.5-4.5"/><circle cx="16" cy="7" r="5"/>`);
  const upload = lucide(`<path d="M12 3v12"/><path d="m8 7 4-4 4 4"/><path d="M5 21h14"/>`);
  const trash = lucide(`<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>`);

  return `
    <div class="page">
      <section class="card create-card">
        <h2>${plus} New speaker profile</h2>
        <div class="create-grid">
          <div class="field">
            <label for="newSpeakerName">Name</label>
            <input id="newSpeakerName" type="text" placeholder="Aria Sterling" />
          </div>
          <div class="field">
            <label for="newSpeakerLang">Language</label>
            <select id="newSpeakerLang">${langs.map((l) => `<option>${l}</option>`).join("")}</select>
          </div>
          <div class="field">
            <label>Reference audio</label>
            <button type="button" class="dropzone" data-action="upload-sample">${upload} Upload .wav / .mp3</button>
          </div>
          <button class="btn btn-primary create-submit" data-action="create-speaker">Create &amp; Process</button>
        </div>
      </section>
      <div class="voice-grid">
        ${MOCK.voices
          .map(
            (v) => `
          <article class="card spk-card">
            <div class="spk-top">
              <div class="spk-ident">
                <span class="spk-avatar" aria-hidden="true">${mic}</span>
                <div>
                  <h3 class="spk-name">${v.name}</h3>
                  <p class="spk-sub">${v.lang} · ${v.code}</p>
                  <button type="button" class="spk-use" data-action="use-voice" data-id="${v.id}">Use in generate</button>
                </div>
              </div>
              ${badge(v.status)}
            </div>
            <div class="spk-meta">
              <div class="spk-meta-row">
                <span>Reference</span>
                <div class="spk-ref">
                  <button class="play" data-action="toggle-play" data-key="${v.id}" data-tip="Play sample">${iconPlay()}</button>
                  <span class="spk-file"><b>${v.file}</b> <em>(${v.duration})</em></span>
                </div>
              </div>
              <div class="spk-meta-row">
                <span>Embedding</span>
                <span class="spk-emb">${v.embedding}</span>
              </div>
              <div class="spk-meta-row">
                <span>Updated</span>
                <span>${v.updated}</span>
              </div>
            </div>
            <div class="spk-actions">
              <button class="btn" data-action="upload-sample">Replace reference</button>
              <button class="btn" data-action="reprocess">Reprocess</button>
              <button class="icon-btn sm" data-action="delete-voice" data-id="${v.id}" data-tip="Remove">${trash}</button>
            </div>
          </article>`
          )
          .join("")}
      </div>
    </div>`;
}

function viewDatasets() {
  return `
    <div class="page">
      <section class="card">
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Dataset</th><th>Files</th><th>Duration</th><th>Quality</th>
                <th>Training status</th><th>Progress</th><th>Model</th><th>Last updated</th>
              </tr>
            </thead>
            <tbody>
              ${MOCK.datasets
                .map(
                  (d) => `
                <tr class="is-click" data-action="open-dataset" data-id="${d.id}">
                  <td><strong>${d.name}</strong></td>
                  <td class="mono">${d.files}</td>
                  <td class="mono">${d.duration}</td>
                  <td class="mono">${d.quality}</td>
                  <td>${badge(d.status)}</td>
                  <td><div class="progress"><span style="width:${d.progress}%;background:${d.status === "Failed" ? "var(--bad)" : "var(--teal)"}"></span></div></td>
                  <td>${d.model}</td>
                  <td class="muted">${d.updated}</td>
                </tr>`
                )
                .join("")}
            </tbody>
          </table>
        </div>
      </section>
    </div>`;
}

function viewAudio() {
  let rows = MOCK.audio.filter((a) => {
    const q = state.audioQuery.toLowerCase();
    const hit = !q || `${a.id} ${a.project} ${a.script} ${a.voice} ${a.model}`.toLowerCase().includes(q);
    const st = state.audioStatus === "All" || a.status === state.audioStatus;
    const vc = state.audioVoice === "All" || a.voice === state.audioVoice;
    return hit && st && vc;
  });

  const key = state.audioSort;
  rows = [...rows].sort((a, b) => {
    const av = a[key];
    const bv = b[key];
    const cmp = typeof av === "number" ? av - bv : String(av).localeCompare(String(bv));
    return state.audioSortDir === "asc" ? cmp : -cmp;
  });

  const th = (id, label) =>
    `<th class="sortable ${state.audioSort === id ? "is-sorted" : ""}" data-sort="${id}">${label}${sortMark(id)}</th>`;

  return `
    <div class="page">
      <div class="filters">
        <label class="filter"><span>Search</span><input id="audioSearch" type="search" placeholder="Script, id, project…" value="${esc(state.audioQuery)}" /></label>
        <label class="filter"><span>Status</span>
          <select id="audioStatus">
            ${["All", "Approved", "In review", "Regenerate", "Draft", "Rejected"]
              .map((s) => `<option ${s === state.audioStatus ? "selected" : ""}>${s}</option>`)
              .join("")}
          </select>
        </label>
        <label class="filter"><span>Voice</span>
          <select id="audioVoice">
            <option>All</option>
            ${[...new Set(MOCK.audio.map((a) => a.voice))]
              .map((v) => `<option ${v === state.audioVoice ? "selected" : ""}>${v}</option>`)
              .join("")}
          </select>
        </label>
        <span class="muted">${rows.length} clips</span>
      </div>
      <section class="card">
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                ${th("id", "Audio")}
                ${th("project", "Project")}
                <th>Script</th>
                ${th("voice", "Voice")}
                ${th("model", "Model")}
                ${th("duration", "Duration")}
                ${th("similarity", "Similarity")}
                ${th("quality", "Quality")}
                ${th("status", "Status")}
                ${th("created", "Created")}
                <th></th>
              </tr>
            </thead>
            <tbody>
              ${
                rows.length
                  ? rows
                      .map(
                        (a) => `
                <tr>
                  <td>
                    <div class="row">
                      <button class="play" data-action="toggle-play" data-key="${a.id}" data-tip="Play clip">${iconPlay()}</button>
                      <span class="mono">${a.id}</span>
                    </div>
                  </td>
                  <td>${a.project}</td>
                  <td><span class="script-clip">${esc(a.script)}</span></td>
                  <td>${a.voice}</td>
                  <td>${a.model}</td>
                  <td class="mono">${a.duration}</td>
                  <td class="mono">${a.similarity}%</td>
                  <td class="mono">${a.quality}</td>
                  <td>${badge(a.status)}</td>
                  <td class="muted">${a.created}</td>
                  <td>
                    <div class="actions">
                      <button class="icon-btn sm" data-action="open-review" data-id="${a.id}" data-tip="Review">${iconReview()}</button>
                      <button class="icon-btn sm" data-action="save-clip" data-tip="Export">${iconExport()}</button>
                    </div>
                  </td>
                </tr>`
                      )
                      .join("")
                  : `<tr><td colspan="11"><div class="empty"><strong>No clips match</strong>Try another status, voice, or search term.</div></td></tr>`
              }
            </tbody>
          </table>
        </div>
      </section>
    </div>`;
}

function viewReview() {
  const r = MOCK.reviews[0];
  const scores = [
    ["Voice Similarity", r.scores.similarity],
    ["Naturalness", r.scores.naturalness],
    ["Pronunciation", r.scores.pronunciation],
    ["Prosody", r.scores.prosody],
  ];

  return `
    <div class="page">
      <div class="page-head">
        <span class="chip">${r.generated.job}</span>
      </div>
      <div class="review-layout">
        <section class="card panel panel-ref">
          <span class="compare-tag">Reference</span>
          <h3>${r.reference.voice}</h3>
          <p class="muted">${r.reference.lang} · ${r.reference.take} · ${r.reference.duration}</p>
          <div class="wave-wrap" style="margin-top:12px"><canvas data-wave="ref-${r.id}"></canvas></div>
          <div class="player">
            <button class="play" data-action="toggle-play" data-key="ref-${r.id}" data-tip="Play reference">${iconPlay()}</button>
            <span class="muted">Studio take</span>
          </div>
        </section>

        <section class="card panel panel-gen">
          <span class="compare-tag">Generated</span>
          <h3>${r.generated.model}</h3>
          <p class="muted">${r.generated.voice} · ${r.generated.duration} · ${r.generated.job}</p>
          <div class="wave-wrap" style="margin-top:12px"><canvas data-wave="gen-${r.id}"></canvas></div>
          <div class="player">
            <button class="play" data-action="toggle-play" data-key="gen-${r.id}" data-tip="Play generated">${iconPlay()}</button>
            <span class="muted">Model output</span>
          </div>
          <p class="muted" style="margin-top:12px;line-height:1.55">${esc(r.script)}</p>
        </section>

        <aside class="card panel">
          <div class="overall">
            <div class="ring" style="--p:${r.scores.overall}"><span>${r.scores.overall}%</span></div>
            <div>
              <strong>Overall quality</strong>
              <p class="muted" style="margin:4px 0 0">AI evaluation</p>
            </div>
          </div>
          <div class="score-list">
            ${scores
              .map(
                ([n, v]) => `
              <div class="score-row">
                <span>${n}</span><b class="mono">${v}%</b>
                <div class="bar"><i style="width:${v}%"></i></div>
              </div>`
              )
              .join("")}
          </div>
          <p style="font-size:13px;line-height:1.55;margin:0 0 8px">${esc(r.feedback)}</p>
          <p class="muted" style="margin:0 0 12px">${esc(r.recommendation)}</p>
          <label class="muted" style="display:block;margin-bottom:6px">Reviewer comments</label>
          <textarea class="comment" id="reviewComment" placeholder="Add a note for the producer…">${esc(state.comment)}</textarea>
          <div class="review-actions">
            <button class="btn btn-good" data-action="approve">Approve</button>
            <button class="btn btn-bad" data-action="reject">Reject</button>
            <button class="btn btn-ghost" data-action="request-regen">Request regeneration</button>
          </div>
        </aside>
      </div>
    </div>`;
}

function viewJobs() {
  const stages = ["Queued", "Processing", "Evaluating", "Review", "Approved"];
  return `
    <div class="page">
      <div class="pipeline">
        ${stages.map((s, i) => `<div class="pipe-step ${i <= 3 ? "is-on" : ""}">${s}</div>`).join("")}
      </div>
      <section class="card">
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th>Job</th><th>Project</th><th>Status</th><th>Progress</th><th>Model</th><th>Voice</th><th>Time</th><th>Error</th></tr>
            </thead>
            <tbody>
              ${MOCK.jobs
                .map(
                  (j) => `
                <tr>
                  <td class="mono">${j.id}</td>
                  <td>${j.project}</td>
                  <td>${badge(j.stage)}</td>
                  <td><div class="progress"><span style="width:${j.progress}%;background:${j.stage === "Failed" ? "var(--bad)" : "var(--teal)"}"></span></div></td>
                  <td>${j.model}</td>
                  <td>${j.voice}</td>
                  <td class="mono">${j.time}</td>
                  <td class="${j.error !== "—" ? "" : "muted"}">${j.error}</td>
                </tr>`
                )
                .join("")}
            </tbody>
          </table>
        </div>
      </section>
    </div>`;
}

function viewModels() {
  return `
    <div class="page">
      <div class="model-grid">
        ${MOCK.models
          .map(
            (m) => `
          <article class="card model-card">
            <div class="row" style="justify-content:space-between">
              <h3>${m.name}</h3>
              <div class="row">${badge(m.type)} ${badge(m.status)}</div>
            </div>
            <div class="model-meta">
              <div>${m.provider} · ${m.version}</div>
              <div>Languages ${m.languages.join(" · ")}</div>
              <div class="mono">${m.endpoint}</div>
              <div>${m.compute} · p50 ${m.latency}</div>
            </div>
            <pre class="cfg">${esc(JSON.stringify(m.config, null, 2))}</pre>
            <button class="btn btn-compact" data-action="open-model" data-id="${m.id}">Configure</button>
          </article>`
          )
          .join("")}
      </div>
    </div>`;
}

function viewAnalytics() {
  const a = MOCK.analytics;
  return `
    <div class="page">
      <div class="kpi-grid" style="grid-template-columns:repeat(4,1fr)">
        <article class="card kpi"><div class="label">Audio generated</div><div class="value">1,842</div><div class="delta">+18% vs prior</div></article>
        <article class="card kpi"><div class="label">Characters processed</div><div class="value">14.6M</div><div class="delta">62% of quota</div></article>
        <article class="card kpi tone-good"><div class="label">Approval rate</div><div class="value">86%</div><div class="delta">+3 pts</div></article>
        <article class="card kpi"><div class="label">Median generation</div><div class="value">52s</div><div class="delta">XTTS p50</div></article>
      </div>
      <div class="grid-2">
        <section class="card chart-card">
          <strong>Audio generated</strong>
          <svg class="line-svg" id="lineChart"></svg>
          <p class="muted">${a.months[0]} — ${a.months.at(-1)}</p>
        </section>
        <section class="card chart-card">
          <strong>Model usage</strong>
          <div class="donut-row" style="margin-top:16px">
            <svg width="120" height="120" id="donutChart"></svg>
            <div class="legend">
              ${a.models.map((m) => `<div><i class="swatch" style="background:${m.color}"></i>${m.name} · ${m.pct}%</div>`).join("")}
            </div>
          </div>
        </section>
      </div>
      <div class="grid-2" style="margin-top:14px">
        <section class="card chart-card">
          <strong>Voice usage</strong>
          <div class="bars" style="margin-top:18px">
            ${a.voices.map((v) => `<i title="${v.name}" style="height:${(v.n / 612) * 100}%"></i>`).join("")}
          </div>
          <div class="row" style="margin-top:8px">${a.voices.map((v) => `<span class="muted">${v.name.split(" ")[0]}</span>`).join("")}</div>
        </section>
        <section class="card chart-card">
          <strong>Quality & reliability</strong>
          <div class="score-list">
            <div class="score-row"><span>Similarity score</span><b class="mono">91.4%</b><div class="bar"><i style="width:91%"></i></div></div>
            <div class="score-row"><span>Approval rate</span><b class="mono">86%</b><div class="bar"><i style="width:86%"></i></div></div>
            <div class="score-row"><span>Failed jobs</span><b class="mono">0.7%</b><div class="bar"><i style="width:8%"></i></div></div>
            <div class="score-row"><span>Generation time (norm.)</span><b class="mono">52s</b><div class="bar"><i style="width:62%"></i></div></div>
          </div>
        </section>
      </div>
    </div>`;
}

function viewAudit() {
  return `
    <div class="page">
      <section class="card">
        <div class="table-wrap">
          <table>
            <thead><tr><th>User</th><th>Action</th><th>Project</th><th>Audio / Job</th><th>Timestamp</th><th>Status</th></tr></thead>
            <tbody>
              ${MOCK.logs
                .map(
                  (l) => `
                <tr>
                  <td>${l.user}</td>
                  <td>${l.action}</td>
                  <td>${l.project}</td>
                  <td class="mono">${l.target}</td>
                  <td class="muted">${l.time}</td>
                  <td>${badge(l.status)}</td>
                </tr>`
                )
                .join("")}
            </tbody>
          </table>
        </div>
      </section>
    </div>`;
}

function viewSettings() {
  const tabs = [
    ["profile", "Profile"],
    ["prefs", "Preferences"],
    ["notify", "Notifications"],
    ["api", "API configuration"],
    ["model", "Model configuration"],
  ];
  const panes = {
    profile: `
      <div class="field"><label>Name</label><input type="text" value="${MOCK.user.name}" /></div>
      <div class="field"><label>Email</label><input type="email" value="${MOCK.user.email}" /></div>
      <div class="field"><label>Role</label><input type="text" value="${MOCK.user.role}" /></div>
      <div class="field"><label>Organization</label><input type="text" value="${MOCK.user.org}" /></div>
      <button class="btn btn-primary" data-action="save-settings">Save profile</button>`,
    prefs: `
      <div class="field"><label>Theme</label>
        <select id="prefTheme"><option value="dark" ${state.theme === "dark" ? "selected" : ""}>Dark</option>
        <option value="light" ${state.theme === "light" ? "selected" : ""}>Light</option></select>
      </div>
      <div class="field"><label>Timezone</label><input type="text" value="${MOCK.user.timezone}" /></div>
      <div class="field"><label>Default model</label><select><option>XTTS v2</option><option>External TTS</option><option>Piper</option></select></div>
      <button class="btn btn-primary" data-action="save-settings">Save preferences</button>`,
    notify: `
      <label class="row" style="margin-bottom:12px"><input type="checkbox" checked /> Job completed</label>
      <label class="row" style="margin-bottom:12px"><input type="checkbox" checked /> Review assigned</label>
      <label class="row" style="margin-bottom:12px"><input type="checkbox" /> Training failed</label>
      <label class="row" style="margin-bottom:16px"><input type="checkbox" checked /> Quota warnings</label>
      <button class="btn btn-primary" data-action="save-settings">Save notifications</button>`,
    api: `
      <p class="muted">Placeholder only. No keys are stored or called.</p>
      <div class="field"><label>Workspace key</label><input type="text" value="as_live_••••••••4e21" /></div>
      <div class="field"><label>Webhook URL</label><input type="text" placeholder="https://example.com/hooks/audio" /></div>
      <button class="btn" data-action="save-settings">Rotate key (demo)</button>`,
    model: `
      <p class="muted">Placeholder for default inference settings. Endpoints are not live.</p>
      <div class="field"><label>Default endpoint region</label><select><option>ap-south-1</option><option>us-east-1</option></select></div>
      <div class="field"><label>Max concurrency</label><input type="text" value="8" /></div>
      <button class="btn btn-primary" data-action="save-settings">Save model defaults</button>`,
  };

  return `
    <div class="page">
      <div class="settings-grid">
        <nav class="card pad settings-nav">
          ${tabs.map(([id, label]) => `<button data-settings="${id}" class="${state.settingsTab === id ? "is-on" : ""}">${label}</button>`).join("")}
        </nav>
        <section class="card pad">${panes[state.settingsTab]}</section>
      </div>
    </div>`;
}

const views = {
  dashboard: viewDashboard,
  projects: viewProjects,
  generate: viewGenerate,
  voices: viewVoices,
  datasets: viewDatasets,
  audio: viewAudio,
  review: viewReview,
  jobs: viewJobs,
  models: viewModels,
  analytics: viewAnalytics,
  audit: viewAudit,
  settings: viewSettings,
};

const PAGE_META = {
  dashboard: ["Dashboard", "Overview of your voice AI workspace"],
  projects: ["Projects", "Production packs, brand programs, and language tracks"],
  generate: ["Generate Audio", "Write a script, lock voice and model, then render a preview"],
  voices: ["Voice Library", "Create profiles, upload reference audio and manage embeddings"],
  datasets: ["Training Datasets", "Corpora feeding fine-tunes — status is mocked"],
  audio: ["Generated Audio", "Every rendered clip, filterable by voice and review status"],
  review: ["Review & Compare", "Side-by-side reference and generated takes"],
  jobs: ["Generation Jobs", "Queued through approval — times and errors are demo data"],
  models: ["Models", "External and local TTS endpoints in this workspace"],
  analytics: ["Analytics", "Trailing twelve months of studio output"],
  audit: ["Audit Logs", "Who touched which project, clip, or job"],
  settings: ["Settings", "Workspace preferences for this demo session"],
};

function hydrateWaves() {
  $$("canvas[data-wave]").forEach((c) => {
    const key = c.dataset.wave;
    Wave.bind(c, key, () => state.play[key]?.p || 0);
  });
  const line = $("#lineChart");
  if (line) Wave.line(line, MOCK.analytics.generated);
  const donut = $("#donutChart");
  if (donut) Wave.donut(donut, MOCK.analytics.models);
}

function render() {
  const fn = views[state.view] || viewDashboard;
  $("#view").innerHTML = fn();
  $$(".nav-item").forEach((a) => a.classList.toggle("is-active", a.dataset.view === state.view));
  const meta = PAGE_META[state.view] || PAGE_META.dashboard;
  $("#pageTitle").textContent = meta[0];
  let lede = meta[1];
  if (state.view === "review") {
    const r = MOCK.reviews[0];
    lede = `${r.id} · ${r.project}`;
  }
  $("#pageLede").textContent = lede;
  hydrateWaves();
  bindView();
}

function navigate(view, extra = {}) {
  closeLayers();
  if (isMobile()) {
    state.collapsed = true;
    $(".app").classList.add("is-collapsed");
  }
  Object.assign(state, extra, { view });
  location.hash = `#/${view}`;
  render();
  $("#view").scrollTop = 0;
}

function bindView() {
  const script = $("#script");
  if (script) {
    script.addEventListener("input", () => {
      state.script = script.value;
      const el = $("#scriptStats");
      if (el) el.textContent = `${script.value.length} characters · ${words(script.value)} words · ~${Math.max(1, Math.round(words(script.value) / 2.4))}s spoken`;
    });
  }

  $$("[data-range]").forEach((input) => {
    input.addEventListener("input", () => {
      const key = input.dataset.range;
      const val = Number(input.value);
      if (key in state) state[key] = val;
      const out = $(`[data-out="${key}"]`);
      if (out) out.textContent = val;
    });
  });

  const map = {
    selProject: "project",
    selVoice: "voice",
    selModel: "model",
    selLang: "language",
    selSpeaker: "speaker",
    selEmotion: "emotion",
  };
  Object.entries(map).forEach(([id, key]) => {
    const el = $(`#${id}`);
    if (!el) return;
    el.addEventListener("change", () => {
      state[key] = el.value;
      if (id === "selVoice") {
        const v = MOCK.voices.find((x) => x.id === el.value);
        if (v) {
          state.speaker = v.speaker;
          state.language = v.lang.includes("Hindi") ? "Hindi" : v.lang;
        }
      }
      if (id === "selModel") render();
    });
  });

  const audioSearch = $("#audioSearch");
  if (audioSearch) {
    audioSearch.addEventListener("input", () => {
      state.audioQuery = audioSearch.value;
      render();
      const next = $("#audioSearch");
      if (next) {
        next.focus();
        next.setSelectionRange(state.audioQuery.length, state.audioQuery.length);
      }
    });
  }
  $("#audioStatus")?.addEventListener("change", (e) => {
    state.audioStatus = e.target.value;
    render();
  });
  $("#audioVoice")?.addEventListener("change", (e) => {
    state.audioVoice = e.target.value;
    render();
  });

  $("#reviewComment")?.addEventListener("input", (e) => {
    state.comment = e.target.value;
  });

  $("#prefTheme")?.addEventListener("change", (e) => {
    setTheme(e.target.value);
  });

  $$("[data-settings]").forEach((b) => {
    b.addEventListener("click", () => {
      state.settingsTab = b.dataset.settings;
      render();
    });
  });

  $("#advParams")?.addEventListener("toggle", (e) => {
    state.advancedOpen = e.target.open;
  });

  $$("th[data-sort]").forEach((th) => {
    th.addEventListener("click", () => {
      const key = th.dataset.sort;
      if (state.audioSort === key) state.audioSortDir = state.audioSortDir === "asc" ? "desc" : "asc";
      else {
        state.audioSort = key;
        state.audioSortDir = "asc";
      }
      render();
    });
  });
}

function setTheme(theme) {
  state.theme = theme;
  document.documentElement.dataset.theme = theme;
  localStorage.setItem("as-theme", theme);
}

function togglePlay(key, btn) {
  const cur = state.play[key];
  Object.keys(state.play).forEach((k) => {
    if (state.play[k].raf) cancelAnimationFrame(state.play[k].raf);
  });
  if (cur?.playing) {
    state.play[key] = { ...cur, playing: false };
    btn.innerHTML = iconPlay();
    return;
  }
  $$(".play").forEach((b) => {
    b.innerHTML = iconPlay();
  });
  const started = performance.now();
  const base = cur?.p && cur.p < 1 ? cur.p : 0;
  const duration = 4200;
  state.play[key] = { playing: true, p: base };
  btn.innerHTML = iconPause();

  const tick = (now) => {
    const rec = state.play[key];
    if (!rec?.playing) return;
    rec.p = Math.min(1, base + (now - started) / duration);
    const canvas = $(`canvas[data-wave="${key}"]`);
    if (canvas) Wave.draw(canvas, key, rec.p);
    const clock = $("#playTime");
    if (clock && key === "preview-gen") {
      const sec = Math.floor(rec.p * 18);
      clock.textContent = `0:${String(sec).padStart(2, "0")}`;
    }
    if (rec.p >= 1) {
      rec.playing = false;
      rec.p = 0;
      btn.innerHTML = iconPlay();
      if (canvas) Wave.draw(canvas, key, 0);
      return;
    }
    rec.raf = requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

document.addEventListener("click", (e) => {
  const go = e.target.closest("[data-go]");
  if (go) {
    const extra = {};
    if (go.dataset.project) extra.project = go.dataset.project;
    navigate(go.dataset.go, extra);
    return;
  }

  const action = e.target.closest("[data-action]");
  if (!action) return;
  const name = action.dataset.action;

  if (name === "generate") {
    if (!state.script.trim()) {
      toast("Add a script before generating.");
      return;
    }
    state.generating = true;
    render();
    toast("Queued on " + state.model + "…");
    setTimeout(() => {
      state.generating = false;
      state.generated = true;
      render();
      toast("Preview ready · 0:18 · demo render");
    }, 900);
  }

  if (name === "sample-script") {
    state.script = MOCK.defaultScript;
    render();
    toast("Sample narration inserted");
  }

  if (name === "save-clip") toast("Saved to Generated Audio (demo)");
  if (name === "send-review") {
    toast("Sent to Review & Compare");
    setTimeout(() => navigate("review"), 350);
  }
  if (name === "upload-sample") {
    openModal(`
      <p class="eyebrow">Voice library</p>
      <h2 style="font-family:var(--serif);margin:6px 0 10px">Upload sample</h2>
      <p class="muted">This control is visual only. No files are stored.</p>
      <div class="field" style="margin-top:14px"><label>Label</label><input type="text" placeholder="Aria warm take 15" /></div>
      <div class="field"><label>File</label><input type="text" value="studio-take-15.wav" disabled /></div>
      <div class="row"><button class="btn btn-primary" data-action="fake-upload">Attach sample</button><button class="btn" id="closeModal">Cancel</button></div>
    `);
  }
  if (name === "fake-upload") {
    closeLayers();
    toast("Sample attached to voice card (demo)");
  }
  if (name === "create-speaker") {
    const label = $("#newSpeakerName")?.value.trim();
    if (!label) {
      toast("Add a speaker name first");
      return;
    }
    const lang = $("#newSpeakerLang")?.value || "English";
    const n = String(MOCK.voices.length + 1).padStart(3, "0");
    MOCK.voices.unshift({
      id: "v-new-" + Date.now(),
      code: "spk-" + n,
      name: label,
      speaker: label.split(/\s+/)[0],
      lang,
      gender: "—",
      duration: "—",
      file: "pending.wav",
      embedding: "—",
      updated: "Just now",
      status: "Processing",
      quality: 0,
      similarity: 0,
      tags: ["New"],
      accent: "",
    });
    render();
    toast(label + " queued for processing (demo)");
  }
  if (name === "reprocess") toast("Reprocess queued (demo)");
  if (name === "delete-voice") {
    const id = action.dataset.id;
    const i = MOCK.voices.findIndex((v) => v.id === id);
    if (i >= 0) MOCK.voices.splice(i, 1);
    render();
    toast("Voice removed from this session (demo)");
  }
  if (name === "use-voice") {
    state.voice = action.dataset.id;
    const v = MOCK.voices.find((x) => x.id === state.voice);
    if (v) {
      state.speaker = v.speaker;
      state.language = v.lang.includes("Hindi") ? "Hindi" : v.lang;
    }
    navigate("generate");
    toast("Voice selected · " + v.name);
  }
  if (name === "toggle-play") togglePlay(action.dataset.key, action);
  if (name === "approve") toast("Clip approved · AUR-1842");
  if (name === "reject") toast("Clip rejected" + (state.comment ? " with comment" : ""));
  if (name === "request-regen") {
    toast("Regeneration requested");
    navigate("generate");
  }
  if (name === "open-review") navigate("review");
  if (name === "save-settings") toast("Settings saved in this browser session (demo)");
  if (name === "new-project") {
    openModal(`
      <p class="eyebrow">Projects</p>
      <h2 style="font-family:var(--serif);margin:6px 0 10px">New project</h2>
      <div class="field"><label>Name</label><input type="text" placeholder="Q4 launch VO" /></div>
      <div class="field"><label>Client</label><input type="text" placeholder="Internal" /></div>
      <div class="row"><button class="btn btn-primary" data-action="create-project">Create</button><button class="btn" id="closeModal">Cancel</button></div>
    `);
  }
  if (name === "create-project") {
    closeLayers();
    toast("Project created (demo)");
  }
  if (name === "open-project") {
    const p = MOCK.projects.find((x) => x.id === action.dataset.id);
    openDrawer(`
      <p class="eyebrow">Project</p>
      <h2 style="font-family:var(--serif);font-size:32px;margin:8px 0">${p.name}</h2>
      <p class="muted">${p.client} · ${p.lang}</p>
      <p style="margin:16px 0">${p.clips} generated clips · ${p.chars} characters processed.</p>
      ${badge(p.status)}
      <div class="row" style="margin-top:20px">
        <button class="btn btn-primary" data-go="generate" data-project="${p.id}">Generate</button>
        <button class="btn" data-go="audio">View audio</button>
      </div>
    `);
  }
  if (name === "open-dataset") {
    const d = MOCK.datasets.find((x) => x.id === action.dataset.id);
    openDrawer(`
      <p class="eyebrow">Dataset</p>
      <h2 style="font-family:var(--serif);font-size:28px;margin:8px 0">${d.name}</h2>
      <p class="muted">${d.files} files · ${d.duration} · quality ${d.quality}</p>
      <p style="margin:14px 0">Target model: ${d.model}</p>
      ${badge(d.status)}
      <div class="progress" style="margin-top:16px"><span style="width:${d.progress}%"></span></div>
      ${d.error ? `<p class="muted" style="margin-top:14px">${d.error}</p>` : ""}
    `);
  }
  if (name === "open-model") {
    const m = MOCK.models.find((x) => x.id === action.dataset.id);
    openDrawer(`
      <p class="eyebrow">${m.type} model</p>
      <h2 style="font-family:var(--serif);font-size:32px;margin:8px 0">${m.name}</h2>
      <p class="muted">${m.provider} · ${m.version}</p>
      <p class="mono" style="margin:16px 0">${m.endpoint}</p>
      <pre class="cfg">${esc(JSON.stringify(m.config, null, 2))}</pre>
      <button class="btn" data-action="save-settings">Save configuration</button>
    `);
  }
});

$("#overlay").addEventListener("click", closeLayers);
document.addEventListener("click", (e) => {
  if (e.target.id === "closeModal") closeLayers();
});

$("#sidebarToggle").addEventListener("click", () => {
  if (isMobile()) {
    const open = !$(".app").classList.contains("is-nav-open");
    $(".app").classList.toggle("is-nav-open", open);
    state.collapsed = !open;
    $("#overlay").hidden = !open;
    return;
  }
  state.collapsed = !state.collapsed;
  $(".app").classList.toggle("is-collapsed", state.collapsed);
  localStorage.setItem("as-collapsed", state.collapsed ? "1" : "0");
});

$("#themeToggle").addEventListener("click", () => {
  setTheme(state.theme === "dark" ? "light" : "dark");
  hydrateWaves();
});

$("#notifyBtn").addEventListener("click", () => {
  openDrawer(`
    <p class="eyebrow">Inbox</p>
    <h2 style="font-family:var(--serif);margin:8px 0 16px">Notifications</h2>
    ${MOCK.activity
      .slice(0, 5)
      .map((a) => `<p style="padding:10px 0;border-bottom:1px solid var(--line)"><strong>${a.action}</strong><br><span class="muted">${a.target} · ${a.time}</span></p>`)
      .join("")}
  `);
});

$("#userChip").addEventListener("click", () => navigate("settings"));

function openPalette() {
  $("#overlay").hidden = false;
  $("#palette").hidden = false;
  $("#palette").innerHTML = `
    <input id="paletteInput" placeholder="Go to a screen…" />
    <div class="palette-list">
      ${[
        ["dashboard", "Dashboard"],
        ["projects", "Projects"],
        ["generate", "Generate Audio"],
        ["voices", "Voice Library"],
        ["datasets", "Training Datasets"],
        ["audio", "Generated Audio"],
        ["review", "Review & Compare"],
        ["jobs", "Generation Jobs"],
        ["models", "Models"],
        ["analytics", "Analytics"],
        ["audit", "Audit Logs"],
        ["settings", "Settings"],
      ]
        .map(([v, label]) => `<button data-go="${v}">${label}</button>`)
        .join("")}
    </div>`;
  $("#paletteInput")?.focus();
}

$("#globalSearch").addEventListener("click", openPalette);
document.addEventListener("keydown", (e) => {
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
    e.preventDefault();
    openPalette();
  }
  if (e.key === "Escape") closeLayers();
});

function parseView() {
  return location.hash.replace("#/", "").split("?")[0] || "dashboard";
}

window.addEventListener("hashchange", () => {
  closeMobileNav();
  const view = parseView();
  if (views[view]) {
    state.view = view;
    render();
  }
});

window.addEventListener("resize", () => {
  if (isMobile() && !state.collapsed) closeMobileNav();
});
window.matchMedia("(max-width: 860px)").addEventListener("change", (e) => {
  if (e.matches) closeMobileNav();
});

const initial = parseView();
if (views[initial]) state.view = initial;
const bootParams = new URLSearchParams(location.search);
if (bootParams.has("ready")) state.generated = true;
if (bootParams.get("theme") === "light" || bootParams.get("theme") === "dark") setTheme(bootParams.get("theme"));
render();
closeMobileNav();
