const Wave = {
  seed(key) {
    let h = 2166136261;
    const s = String(key);
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return () => {
      h += 0x6d2b79f5;
      let t = h;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  },

  samples(key, n = 96) {
    const rand = this.seed(key);
    const out = [];
    for (let i = 0; i < n; i++) {
      const env = Math.sin((i / (n - 1)) * Math.PI) ** 0.65;
      const grain = 0.35 + rand() * 0.65;
      const dip = rand() > 0.92 ? 0.15 : 1;
      out.push(Math.max(0.06, env * grain * dip));
    }
    return out;
  },

  draw(canvas, key, progress = 0, opts = {}) {
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth || 300;
    const h = canvas.clientHeight || 80;
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);

    const samples = this.samples(key, opts.bars || Math.max(48, Math.floor(w / 5)));
    const gap = 2;
    const barW = (w - gap * samples.length) / samples.length;
    const mid = h / 2;
    const played = opts.colorPlayed || getComputedStyle(document.documentElement).getPropertyValue("--accent").trim() || "#34d399";
    const rest = opts.colorRest || "rgba(179, 172, 158, 0.35)";

    samples.forEach((amp, i) => {
      const x = i * (barW + gap);
      const bh = Math.max(3, amp * (h * 0.86));
      ctx.fillStyle = i / samples.length <= progress ? played : rest;
      ctx.beginPath();
      const bw = Math.max(1.4, barW);
      const by = mid - bh / 2;
      if (ctx.roundRect) ctx.roundRect(x, by, bw, bh, 2);
      else ctx.rect(x, by, bw, bh);
      ctx.fill();
    });

    if (progress > 0 && progress < 1) {
      const px = progress * w;
      ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--accent").trim() || "#e8a54b";
      ctx.fillRect(px, 8, 1.5, h - 16);
    }
  },

  bind(canvas, key, getProgress) {
    const paint = () => this.draw(canvas, key, getProgress ? getProgress() : 0);
    paint();
    const ro = new ResizeObserver(paint);
    ro.observe(canvas);
    return { paint, stop: () => ro.disconnect() };
  },

  line(svg, values) {
    if (!svg) return;
    const max = Math.max(...values);
    const min = Math.min(...values);
    const w = 100;
    const h = 40;
    const pts = values
      .map((v, i) => {
        const x = (i / (values.length - 1)) * w;
        const y = h - ((v - min) / (max - min || 1)) * (h - 6) - 3;
        return `${x},${y}`;
      })
      .join(" ");
    const start = `${0},${h} ${pts} ${w},${h}`;
    svg.innerHTML = `
      <defs>
        <linearGradient id="lg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="var(--accent)" stop-opacity="0.35"/>
          <stop offset="100%" stop-color="var(--accent)" stop-opacity="0"/>
        </linearGradient>
      </defs>
      <polygon points="${start}" fill="url(#lg)"/>
      <polyline points="${pts}" fill="none" stroke="var(--accent)" stroke-width="1.6" vector-effect="non-scaling-stroke"/>
    `;
    svg.setAttribute("viewBox", `0 0 ${w} ${h}`);
    svg.setAttribute("preserveAspectRatio", "none");
  },

  donut(svg, segments) {
    const r = 28;
    const c = 2 * Math.PI * r;
    let offset = 0;
    const circles = segments
      .map((s) => {
        const len = (s.pct / 100) * c;
        const el = `<circle cx="36" cy="36" r="${r}" fill="none" stroke="${s.color}" stroke-width="8"
          stroke-dasharray="${len} ${c - len}" stroke-dashoffset="${-offset}" />`;
        offset += len;
        return el;
      })
      .join("");
    svg.setAttribute("viewBox", "0 0 72 72");
    svg.innerHTML = `<circle cx="36" cy="36" r="${r}" fill="none" stroke="var(--surface-3)" stroke-width="8"/>${circles}`;
  },
};
