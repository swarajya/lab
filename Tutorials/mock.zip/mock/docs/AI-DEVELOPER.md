# Audio Studio — AI workflow

How the AI developer works. Product screens and API: [AUDIO-STUDIO.md](AUDIO-STUDIO.md).

You own models. You take samples, train or fine-tune, then generate audio with that model. Local models are first-class (XTTS, Piper, Custom). External TTS is used only when the user picks it.

## Loop

```
sample → embedding Ready
      → dataset + target model
      → train / fine-tune → checkpoint
      → generate script on that model
      → evaluate → review (approve / reject / regenerate)
```

Example: upload a Brand Voice sample → train Custom TTS on the Brand Voice corpus → generate a script with that checkpoint → send to review.

## 1. Sample — Voice Library

Create a speaker (name, language). Upload `.wav` or `.mp3`. **Create & Process** builds the embedding.

Also: play reference, **Replace reference**, **Reprocess**, **Use in generate**, delete.

A voice with no embedding cannot generate.

| Status | Meaning | Next step |
|---|---|---|
| Processing | Encoder is running | Wait |
| Ready | Embedding exists | Use in generate or add to a dataset |
| Failed | Sample or encode failed | Fix the file, Reprocess |

## 2. Train / fine-tune — Training Datasets

A dataset is samples aimed at one model. It shows files, duration, quality, target model, status, progress, and error.

| Status | Meaning |
|---|---|
| Processing | Train / fine-tune is running |
| Completed | Checkpoint is ready to generate |
| Failed | Store the error (alignment, phoneme timeout, and so on) and fix |

Start train from the dataset. The worker writes checkpoints. A project stays `Training` until its corpus completes.

External TTS has no train job. Local models do.

## 3. Models

Each model has type, provider, version, languages, endpoint, compute, latency, and config. Edit knobs on this screen and on Generate → Advanced.

| Model | Type | You do |
|---|---|---|
| XTTS v2 | Local | Fine-tune a speaker, then generate |
| Piper | Local | Train / export a voice, then generate |
| Custom TTS | Local | Train a brand / custom voice; generate with a checkpoint (epoch-12 / 18 / 24) |
| External TTS | Remote | Generate only |

| Status | Meaning |
|---|---|
| Healthy | May generate |
| Training | Learning; generate from a named checkpoint only if allowed |
| Degraded | Process is weak or down; show it; do not switch engines |

## 4. Generate — Generate Audio

Need a **Ready** voice and the model the user picked.

1. Pick project, voice, model.
2. Paste a script (max 5,000 characters).
3. Set language, speaker, emotion / style.
4. Set speed, pitch, volume, stability, similarity.
5. Set that model’s advanced knobs.
6. **Generate audio**. A job queues on that model.
7. Play preview. **Save**, **Send to review**, or **Regenerate**.

Knobs:

- External TTS — style exaggeration, speaker boost
- XTTS v2 — temperature, top-p, repetition penalty
- Piper — noise scale, length scale
- Custom TTS — CFG scale, checkpoint

Quota counts characters. Stock local models can generate without a fine-tune. Fine-tuned models generate with their checkpoint.

## 5. Jobs, review, audit

Generate path:

```
Queued → Processing → Evaluating → Review → Approved
                                         ↘ Failed / Rejected
```

Save without review = Draft. Request regeneration starts a new job (often with a knob change).

Review plays reference vs generated. Scores: similarity, naturalness, pronunciation, prosody, overall. Then approve, reject (with comment), or regenerate.

Train path: Processing → Completed, or Failed with the error on the dataset.

Audit every sample upload, train start, train fail, model config change, generate, approve, and reject.

## Full path example

**Custom brand voice**

1. Upload samples on the brand speaker. Status must become Ready.
2. Put them in a corpus aimed at Custom TTS.
3. Train. Custom TTS stays Training until a checkpoint is written.
4. Generate that voice + Custom TTS + checkpoint → clip → review.

**Speaker fine-tune**

1. Ready sample on the speaker.
2. Dataset aimed at XTTS v2 completes.
3. Generate that voice + XTTS v2 → clip → approve.

## Code

Domain does not import Fastify, Prisma, Redis, React, or a TTS library. New vendor = new adapter on the same port.

```
apps/web/src/{domain,application,infrastructure,ui}
apps/api/src/modules/<area>/{domain,application,infrastructure,interface/http}
apps/worker/          generate + train jobs
packages/contracts    shared types
```

| Port | Does |
|---|---|
| `SampleStore` | Save reference takes |
| `EmbeddingEngine` | Sample → embedding |
| `TrainingEngine` | Dataset + base model → checkpoint |
| `TtsEngine` | Script + voice + model → audio |
| `QualityEvaluator` | Reference + clip → scores |
| `ModelRegistry` | List, health, endpoint, config |
| `JobQueue` | Enqueue generate or train |
| `ObjectStorage` | Audio and checkpoints |

Worker, generate: claim → `TtsEngine` → `QualityEvaluator` → save clip.

Worker, train: claim → `TrainingEngine` → write checkpoint → model Healthy or Failed.

### Add a model

1. Implement `TtsEngine`. If it can learn, also `TrainingEngine`.
2. Register name, Local or External, endpoint, languages, knobs.
3. Wire knobs to Generate and Models.
4. Fine-tune only from a dataset that lists this model.
5. Generate when Healthy. Training + a named checkpoint only when the domain allows it.

## Must hold

- Sample → embedding → voice Ready before generate.
- Failed voice can Reprocess to Ready.
- Train completes with a usable checkpoint, or stores the error.
- Fine-tuned local generate works. Stock local generate works.
- Degraded / Training is visible. The engine does not change by itself.
- Review can approve, reject, or regenerate.
- Quota counts characters.
- Tests use fake ports. One adapter test per local model you enable.
- No model weights or secrets in git.

## Do not

- Put SQL, HTTP, or TTS imports in `domain`.
- Run train without `TrainingEngine`.
- Generate from a Processing or Failed voice.
- Force External TTS when the user picked a local model.
