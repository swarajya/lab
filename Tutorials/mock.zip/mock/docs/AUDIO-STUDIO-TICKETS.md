# Audio Studio tickets

Two backlogs and builder help. Nothing is filed in Jira unless asked.

| File | Owner | Covers |
| --- | --- | --- |
| [FULLSTACK-TICKETS.md](FULLSTACK-TICKETS.md) | Fullstack (frontend + backend) | Screens, APIs, queue, files, quota, review actions |
| [AI-ML-TICKETS.md](AI-ML-TICKETS.md) | AI/ML developer | Voice prepare, generate, train, validate, compare |

## Engineering help (no meeting needed)

Give the developer one file: [help/tickets/README.md](help/tickets/README.md).

**Browser:** from the repo root run `python3 -m http.server 4173`, then open [help/view.html](help/view.html) (`http://127.0.0.1:4173/docs/help/view.html`). A raw `.md` URL is not formatted HTML.

Each of F1–F13 and M1–M11 has its own doc: visual contract, APIs, integrate steps, mock replacements, tests, depends on, and **If blocked** (file links only).

| File | What it is |
| --- | --- |
| [help/tickets/README.md](help/tickets/README.md) | Per-ticket engineering pack |
| [help/ARCHITECTURE.md](help/ARCHITECTURE.md) | Apps, areas, ports |
| [help/GET-HELP.md](help/GET-HELP.md) | Symptom → ticket file |
| [help/screenshots/](help/screenshots/) | Mock captures |

## Split

| Fullstack | AI/ML |
| --- | --- |
| F1–F13 | M1–M11 |
| Pages and save/load | Embeddings, train, speak, score |
| Start generate / train jobs | Make the audio and the scores |
| Review buttons and players | Comparison scores vs the reference |

## Sources

| Doc |
| --- |
| [AUDIO-STUDIO.md](AUDIO-STUDIO.md) |
| [AI-DEVELOPER.md](AI-DEVELOPER.md) |
