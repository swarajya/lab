# Fullstack tickets — frontend and backend

Backlog for one **fullstack developer**. Each ticket is a full slice: the screen and the APIs that save and load data.

The mock screens are the look. Do not redesign. Voice generation, scoring, and model training are in [AI-ML-TICKETS.md](AI-ML-TICKETS.md).

**Implement from the ticket file, not a chat:** [help/tickets/README.md](help/tickets/README.md)

Do not file these in Jira unless asked.

**Epic:** Bring up the Audio Studio app so people can run a voice job from project to review  
**Assignee (all tickets):** Fullstack (frontend + backend)

## How this sits next to AI/ML

| Fullstack does | AI/ML does |
| --- | --- |
| Pages, APIs, save/load, queue, files, quota | Embeddings, train, generate audio, score / compare |

## All tickets

| ID | Title | Screen | You build | After | Hands off to |
| --- | --- | --- | --- | --- | --- |
| F1 | Stand up the studio apps, sign-in, and the character budget | Shell, quota bar, search, theme, notifications | Web app, API, worker shell, sign-in, layout, quota, job queue, file storage | — | — |
| F2 | Start a project and open it later | Projects | Projects page and save / load | F1 | — |
| F3 | Add a speaker and show if the voice is ready | Voice Library | Voice page, upload, play, replace, delete, status from the process | F1 | M1, M2 |
| F4 | List models and save their settings | Models | Models page and save knobs / defaults | F1 | M4, M5 |
| F5 | Start a generate job from a script | Generate Audio | Generate page, start-job API, preview player, save draft, send to review | F1, F2, F3, F4 | M6, M7, M9 |
| F6 | Show where each job is | Generation Jobs | Jobs page and status from the queue | F5 | — |
| F7 | Find a clip, play it, and download it | Generated Audio | Clip list, search, filters, play, export | F5 | — |
| F8 | Compare takes and record the decision | Review & Compare | Side-by-side players, comment, approve / reject / try again | F7 | M10 |
| F9 | Start a train job from a dataset | Training Datasets | Datasets page, start-train API, progress and error on the row | F3, F4 | M3, M8 |
| F10 | Show how the studio is doing today | Dashboard | Home numbers, recent clips, activity, job counts | F6, F8 | — |
| F11 | Show what we made over time | Analytics | Volume, model mix, voice mix, quality charts | F10 | — |
| F12 | Show who did what | Audit Logs | History table; write a row when important things happen | F5 | — |
| F13 | Update profile and studio defaults | Settings | Profile, preferences, alerts, API key, model defaults | F1 | — |

## Build order

| Step | Tickets | Why this order |
| --- | --- | --- |
| 1 | F1 | App, sign-in, quota, queue, and files must exist |
| 2 | F2, F3, F4 | Enough catalog to generate |
| 3 | F5, F6, F7 | Make a take, watch it, find it |
| 4 | F8 | Review and decide |
| 5 | F9 | Train after generate works |
| 6 | F10, F11, F12, F13 | Home, charts, history, settings |

## Ticket details

| ID | Who | They want | So that | Done when |
| --- | --- | --- | --- | --- |
| F1 | Anyone on the team | To open the studio, sign in, and see how much of our character budget is left | The product is a real app | I can sign in and see my name, role, and company. The quota bar matches what we have used. I get a warning at 80% and cannot start a script that would go over. Jobs can sit on a queue and be checked later (no live push). All twelve screens open. |
| F2 | Audio engineer | To create a project and open it later | Work is grouped by client job | I can create a project (name and client). Opening it shows clips, characters, language, and status. Generate already has that project selected. A project still being trained stays marked Training until that work finishes. Data comes from the API, not the mock. |
| F3 | AI developer | To add a speaker, upload a file, and see Processing / Ready / Failed | We know which voices can be used | I can name a speaker, pick a language, upload `.wav` or `.mp3`. I can play, replace, or delete. Only Ready voices can be sent to generate. The page shows live status. The encode itself is AI/ML (M1, M2). |
| F4 | AI developer or admin | To see models and save how they should speak | People pick an engine on the page | I can see type, health, languages, and endpoint for External TTS, XTTS v2, Piper, and Custom TTS. I can save settings. Health and speak behaviour come from AI/ML (M4, M5). The app never swaps the model the person picked. |
| F5 | Audio engineer | To paste a script, pick project, voice, and model, and start a take | We can request a generate | I cannot start an empty script or one over 5,000 characters. I must pick a Ready voice and a model. Save keeps a draft. Send to review opens Review. Try again starts a new job. Characters count against quota. The audio file is made by AI/ML (M6, M7, M9). |
| F6 | Engineer or reviewer | To see job stage, progress, and errors | Nobody is guessing if work is stuck | A generate job shows Queued → Processing → Evaluating → Review → Approved, or Failed / Rejected. A train job shows Processing → Completed or Failed. Failed rows show the error. The list updates as work progresses. |
| F7 | Audio engineer | To search takes, filter them, play one, or download it | We can find any clip | I can search by script, id, or project. I can filter by Approved, In review, Regenerate, Draft, or Rejected. I can play and download stored audio. Review opens that clip. Empty search shows "No clips match". |
| F8 | Reviewer | To hear original and new take side by side, leave a note, and decide | We only keep takes that sound right | I can play both takes. I can leave a comment. Approve, Reject, and Request regeneration update the clip. A new take sends me back to Generate. Scores on the page come from AI/ML (M10). |
| F9 | AI developer | To see datasets and start training | We can kick off a train job | I can see files, duration, quality, target model, status, progress, and error. I can start train on a local model. External TTS cannot be trained. Progress and errors show on the row. The train itself is AI/ML (M8). |
| F10 | Anyone on the team | A home page that shows what needs attention | We know what to do today | Numbers match real work. I can jump to Generate, Jobs, or Generated Audio. Recent clips and activity take me to the right place. |
| F11 | Engineer or admin | To see volume, model mix, voice mix, and pass rate | We can see how the studio is performing | I can see how much audio we made, which models and voices we use, approval rate, similarity, failures, and typical wait time. |
| F12 | Admin or lead | A history of important actions | We can answer "who changed this?" | I can see who, what, which project, which clip or job, when, and the result. We log sample upload, train start, train fail, model setting change, generate, approve, and reject. |
| F13 | Anyone / admin | To change profile, theme, alerts, and admin defaults | The studio fits how we work | I can save name, email, theme, timezone, and default model. I can turn alerts on or off for job done, review assigned, training failed, and quota warnings. An admin can rotate the workspace key. Secrets never go into git. |

## Rules for fullstack

| Rule |
| --- |
| Keep the current screens. Do not redesign |
| Pages talk to the API, not the mock files |
| Jobs are checked on a timer. No live push |
| Quota is enforced before a generate starts |
| Do not build the encode, train, speak, or score engines — those are AI/ML |

## Out of scope

| Do not ticket here |
| --- |
| Embeddings, training, voice generation, quality scores |
| Charging money |
| A new visual design |
| Live push updates |

## Sources

| Doc / screen |
| --- |
| [AUDIO-STUDIO.md](AUDIO-STUDIO.md) |
| [AI-ML-TICKETS.md](AI-ML-TICKETS.md) |
| All twelve mock screens |
