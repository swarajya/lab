# AI/ML tickets — voice generation, validation, and comparison

Backlog for one **AI/ML developer**. This is model work: prepare a voice, generate speech, score it, and compare it to the reference.

Pages and APIs are in [FULLSTACK-TICKETS.md](FULLSTACK-TICKETS.md). Screens below are only a reference for what the process must support.

**Implement from the ticket file, not a chat:** [help/tickets/README.md](help/tickets/README.md)

Do not file these in Jira unless asked. Do not put model weights or secrets in git.

**Epic:** Stand up voice generation, validation, and comparison  
**Assignee (all tickets):** AI/ML developer

## What this backlog covers

| Area | Meaning |
| --- | --- |
| Prepare | Sample → embedding → Ready voice; dataset for train |
| Generate | Stock local, External TTS, and checkpoint speech |
| Train | Fine-tune / train to a checkpoint |
| Validate and compare | Score the take vs the reference; support approve / reject / try again |

## All tickets

| ID | Title | Area | Look at | You build | After |
| --- | --- | --- | --- | --- | --- |
| M1 | Turn a recording into a Ready voice | Prepare | Voice Library | Store the take and build an embedding | — |
| M2 | Fix a failed encode and try again | Prepare | Voice Library | Reprocess and replace so Failed can become Ready | M1 |
| M3 | Build a dataset aimed at one model | Prepare | Training Datasets | Group Ready samples; files, length, quality, target model | M1 |
| M4 | Report model health and never swap engines | Prepare | Models | Health for XTTS v2, Piper, Custom TTS, External TTS | — |
| M5 | Apply the knobs each model uses when it speaks | Generate | Models, Generate → Advanced | Per-model settings on the next generate | M4 |
| M6 | Generate speech with a stock local model | Generate | Generate Audio | XTTS v2 and Piper speak with no fine-tune | M1, M4, M5 |
| M7 | Generate speech with External TTS only when it is chosen | Generate | Generate Audio | Remote speak. Never used unless someone picked it | M4, M5 |
| M8 | Train or fine-tune a local model to a checkpoint | Train | Training Datasets | Checkpoint or a clear error | M3, M4 |
| M9 | Generate speech with a named checkpoint | Generate | Generate Audio | Custom TTS (and other fine-tunes) use epoch-12 / 18 / 24 | M6, M8 |
| M10 | Score and compare the new take to the original | Validate and compare | Review & Compare | Similarity, naturalness, pronunciation, prosody, overall | M6 |
| M11 | Prove each model with a fake test | Safety | — | One adapter test per local model. No weights or secrets in git | M6, M7, M8 |

## Build order

| Step | Tickets | Why this order |
| --- | --- | --- |
| 1 | M1, M2 | A voice must be Ready before generate or train |
| 2 | M3, M4, M5 | Dataset, health, and knobs |
| 3 | M6, M7 | Voice generation (stock local and optional External) |
| 4 | M10 | Validation and comparison |
| 5 | M8, M9 | Train, then generate from a checkpoint |
| 6 | M11 | Tests before adding more models |

## Ticket details

| ID | Who | They want | So that | Done when |
| --- | --- | --- | --- | --- |
| M1 | AI/ML developer | To take a `.wav` or `.mp3` and get a Ready voice | We only generate or train with a prepared speaker | Processing means the encoder is running. Ready means an embedding exists. Failed means the file or encode broke. A voice with no embedding cannot generate. |
| M2 | AI/ML developer | To replace a bad file or reprocess a Failed voice | A broken encode can be fixed | Reprocess can take Failed to Ready. Replace stores a new file and starts process again. |
| M3 | AI/ML developer | To put Ready samples in a dataset aimed at one local model | Training has a clear corpus and target | Dataset can report files, duration, quality, and target model. External TTS has no train. |
| M4 | AI/ML developer | To report whether each model is fit to use | Generate uses a healthy engine on purpose | Healthy may generate. Training may generate only with a named checkpoint if allowed. Degraded is visible. The process never switches engines by itself. |
| M5 | AI/ML developer | To apply how each model should speak | The next generate uses those settings | External TTS: style exaggeration, speaker boost. XTTS v2: temperature, top-p, repetition penalty. Piper: noise scale, length scale. Custom TTS: CFG scale, checkpoint. |
| M6 | AI/ML developer | To generate a script on stock XTTS v2 or Piper | We can make a take without training first | Needs a Ready voice. Script max 5,000 characters. Characters count against quota. Processing or Failed voices cannot generate. The model that was picked is the model that runs. |
| M7 | AI/ML developer | To generate on External TTS only when it is picked | Local work is not sent to a remote engine | External TTS has no train job. Picking XTTS, Piper, or Custom never routes to External TTS. |
| M8 | AI/ML developer | To train or fine-tune a dataset and get a checkpoint | We have something we can generate with | XTTS v2 can be fine-tuned. Piper can train / export a voice. Custom TTS writes checkpoints. Completed means a checkpoint is ready. Failed stores a readable error (alignment, phoneme timeout, and so on). Train only runs through the train step. |
| M9 | AI/ML developer | To generate with a fine-tuned model and a named checkpoint | Brand and speaker trains are usable | Custom TTS can generate with epoch-12, epoch-18, or epoch-24. Fine-tune only from a dataset that lists that model. Stock local generate still works. |
| M10 | AI/ML developer | To validate a clip by comparing it to the reference | Reviewers can see if the take is close enough | After generate, evaluate runs. Scores: similarity, naturalness, pronunciation, prosody, overall. Comparison supports approve, reject, or generate again. |
| M11 | AI/ML developer | To add models without leaking weights | A new vendor is just a new adapter | Tests use fake engines. Each local model we enable has one adapter test. Domain code does not import SQL, HTTP, or a TTS library. No model weights or secrets in git. |

## Paths this process must support

| Path | Steps | Tickets |
| --- | --- | --- |
| Custom brand voice | Upload brand samples → Ready → corpus aimed at Custom TTS → train → generate with checkpoint → score and compare | M1, M3, M8, M9, M10 |
| Speaker fine-tune | Ready sample → dataset aimed at XTTS v2 completes → generate that voice + XTTS v2 → score and compare | M1, M3, M8, M6, M10 |

## Rules that must stay true

| Rule |
| --- |
| Sample → embedding → voice Ready before generate |
| Failed voice can reprocess to Ready |
| Train finishes with a usable checkpoint, or stores the error |
| Fine-tuned local generate works. Stock local generate works |
| Degraded / Training is visible. The engine does not change by itself |
| A take can be scored, then approved, rejected, or run again |
| Quota counts characters |
| Tests use fake ports. One adapter test per local model you enable |
| No model weights or secrets in git |
| Do not generate from a Processing or Failed voice |
| Do not force External TTS when a local model was picked |
| Do not train without the train step |

## Out of scope

| Do not ticket here |
| --- |
| Sign-in, pages, dashboard, analytics, settings (see fullstack file) |
| Charging money |
| A new visual design |
| Live push updates |

## Sources

| Doc |
| --- |
| [AI-DEVELOPER.md](AI-DEVELOPER.md) |
| [AUDIO-STUDIO.md](AUDIO-STUDIO.md) |
| [FULLSTACK-TICKETS.md](FULLSTACK-TICKETS.md) |
