# AI/ML help — how to build each ticket

For engineers implementing [AI-ML-TICKETS.md](../AI-ML-TICKETS.md). This is encode, train, speak, and score. Pages are fullstack.

Read first: [ARCHITECTURE.md](ARCHITECTURE.md) and [GET-HELP.md](GET-HELP.md).

Handoff: fullstack starts the job. You implement the port the worker calls.

---

## M1 — Turn a recording into a Ready voice

### What done looks like

![Voice Library](screenshots/voices.png)

Look at: **Voice Library** — Processing / Ready / Failed

### Architecture

- Area: Catalog
- Ports you own: `SampleStore`, `EmbeddingEngine`
- Worker: claim process job → encode → write embedding → status Ready or Failed
- Fullstack page: F3

### How to integrate

1. Fullstack stores the multipart file and enqueues process.
2. `EmbeddingEngine` reads the file and writes an embedding.
3. Ready = embedding exists. No embedding = cannot generate.
4. Register the port in the worker. Domain does not import a TTS library.

### What to fix in the mock

- Create & Process only adds a fake Processing card.
- No encoder runs. Embeddings in `mock-data/voices.json` are strings.

### Get help

- Loop: [AI-DEVELOPER.md](../AI-DEVELOPER.md) Sample
- Upload never reaches you: F3
- Ports: [ARCHITECTURE.md](ARCHITECTURE.md)

---

## M2 — Fix a failed encode and try again

### What done looks like

![Failed voice](screenshots/voices-failed.png)

Look at: **Voice Library** — Failed card, Reprocess, Replace reference

### Architecture

- Same ports as M1
- `POST /voices/:id/reprocess` and replace-reference enqueue the same encode path

### How to integrate

1. Reprocess runs `EmbeddingEngine` again on the stored file.
2. Replace stores a new file, then process.
3. Failed → Ready is required. Do not make the user create a new speaker.

### What to fix in the mock

- Reprocess only toasts.
- Brahma Brand stays Failed forever.

### Get help

- Encode path: M1
- Button does nothing: F3

---

## M3 — Build a dataset aimed at one model

### What done looks like

![Training Datasets](screenshots/datasets.png)

Look at: **Training Datasets**

### Architecture

- Area: Catalog
- You define what a valid corpus is (Ready samples, one local target model)
- Fullstack lists and starts train: F9

### How to integrate

1. Dataset = Ready samples + one local target (XTTS, Piper, or Custom).
2. Report files, duration, quality.
3. External TTS has no dataset train.

### What to fix in the mock

- `mock-data/datasets.json` is static. There is no create-corpus API wired.

### Get help

- Train job itself: M8
- Page / start button: F9
- [AI-DEVELOPER.md](../AI-DEVELOPER.md) Train / fine-tune

---

## M4 — Report model health and never swap engines

### What done looks like

![Models](screenshots/models.png)

Look at: **Models** — Healthy / Training / Degraded

### Architecture

- Port you own: `ModelRegistry`
- Fullstack displays `GET /models`: F4

### How to integrate

1. Report type, languages, endpoint, compute, latency, health for External TTS, XTTS v2, Piper, Custom TTS.
2. Healthy may generate. Training may generate only with a named checkpoint if allowed. Degraded is visible.
3. The process never switches the person to another engine.

### What to fix in the mock

- Health is hardcoded (Piper Degraded, Custom Training).
- No live probe of the endpoint.

### Get help

- Page save: F4
- Speak still uses the wrong engine: M6 / M7
- [AI-DEVELOPER.md](../AI-DEVELOPER.md) Models

---

## M5 — Apply the knobs each model uses when it speaks

### What done looks like

![XTTS advanced knobs](screenshots/generate-xtts-advanced.png)

![Model configure](screenshots/models-configure.png)

Look at: **Models** and **Generate → Advanced**

### Architecture

- `ModelRegistry` config + `TtsEngine` / External adapter must read the same knobs
- Fullstack saves `PATCH /models/:id/config`: F4

### How to integrate

1. External TTS: style exaggeration, speaker boost.
2. XTTS v2: temperature, top-p, repetition penalty.
3. Piper: noise scale, length scale.
4. Custom TTS: CFG scale, checkpoint.
5. Next generate uses the saved values. Both screens stay in sync.

### What to fix in the mock

- Sliders only change local `state`. They are not sent to a model.

### Get help

- UI not saving: F4 / F5
- Speech ignores knobs: your `TtsEngine` adapter (M6 / M7 / M9)

---

## M6 — Generate speech with a stock local model

### What done looks like

![Generate preview](screenshots/generate-preview.png)

Look at: **Generate Audio** with XTTS v2 or Piper

### Architecture

- Port you own: `TtsEngine` (local adapters)
- Worker: claim → `TtsEngine` → `QualityEvaluator` → save clip
- Fullstack starts the job: F5

### How to integrate

1. Implement local speak for XTTS v2 and Piper. No fine-tune required.
2. Require a Ready voice. Refuse Processing or Failed.
3. Run the model the job named. Never route to External TTS.
4. Script max 5,000 characters. Quota is counted by fullstack (F1 / F5).

### What to fix in the mock

- Generate is a timer. No audio file is written.

### Get help

- Job never queued: F5
- Voice not Ready: M1
- Must not swap engines: M7
- [AI-DEVELOPER.md](../AI-DEVELOPER.md) Generate

---

## M7 — Generate speech with External TTS only when it is chosen

### What done looks like

![External TTS advanced](screenshots/generate-external-advanced.png)

Look at: **Generate Audio** with External TTS selected

### Architecture

- Port: `TtsEngine` remote adapter
- No `TrainingEngine` for External TTS

### How to integrate

1. Remote speak only when the job’s model is External TTS.
2. Picking XTTS, Piper, or Custom must not call the remote adapter.
3. No train job for External TTS.

### What to fix in the mock

- Model select only changes labels. Every generate is the same fake preview.

### Get help

- Job start: F5
- Local speak: M6
- Rule: [AI-DEVELOPER.md](../AI-DEVELOPER.md) Do not force External TTS

---

## M8 — Train or fine-tune a local model to a checkpoint

### What done looks like

![Datasets](screenshots/datasets.png)

![Failed train error](screenshots/datasets-failed-drawer.png)

Look at: **Training Datasets** — Processing / Completed / Failed

### Architecture

- Port you own: `TrainingEngine`
- Worker: claim → train → write checkpoint → model Healthy or Failed
- Fullstack starts `POST /datasets/:id/train`: F9

### How to integrate

1. XTTS v2 fine-tune. Piper train / export. Custom TTS writes checkpoints.
2. Completed = usable checkpoint. Failed = store a readable error (alignment, phoneme timeout).
3. Train only through this port. External TTS cannot train.
4. Project stays Training until the corpus completes.

### What to fix in the mock

- Progress bars are static. No checkpoint files. Error text is fixture data.

### Get help

- Start button / poll: F9
- Dataset rules: M3
- Then speak from checkpoint: M9

---

## M9 — Generate speech with a named checkpoint

### What done looks like

![Custom TTS checkpoint](screenshots/generate-custom-checkpoint.png)

Look at: **Generate Audio** — Custom TTS, checkpoint epoch-12 / 18 / 24

### Architecture

- `TtsEngine` for Custom (and other fine-tunes) + checkpoint from M8
- While Training, generate from a named checkpoint only if the domain allows it

### How to integrate

1. Fine-tune only from a dataset that lists this model.
2. Generate with the chosen epoch. Stock local generate (M6) still works.
3. Do not swap to External TTS.

### What to fix in the mock

- Checkpoint select does not change the demo render.

### Get help

- No checkpoint on disk: M8
- Job start: F5
- [AI-DEVELOPER.md](../AI-DEVELOPER.md) Custom brand voice path

---

## M10 — Score and compare the new take to the original

### What done looks like

![Review compare and scores](screenshots/review.png)

Look at: **Review & Compare**

### Architecture

- Port you own: `QualityEvaluator`
- Worker, after speak: reference + clip → scores
- Fullstack shows scores and buttons: F8

### How to integrate

1. After generate, evaluate.
2. Return similarity, naturalness, pronunciation, prosody, overall.
3. Comparison supports approve, reject, or generate again (F8 owns the buttons).

### What to fix in the mock

- Scores are hardcoded in `mock-data/reviews.json`.
- No evaluator runs after the fake generate.

### Get help

- Buttons / comment: F8
- No clip to score: M6
- [AI-DEVELOPER.md](../AI-DEVELOPER.md) Review scores

---

## M11 — Prove each model with a fake test

No screen. This is safety.

### Architecture

- Tests call fake ports, not live GPU
- Each enabled local model has one adapter test
- Domain does not import SQL, HTTP, or a TTS library
- New vendor = new adapter on the same port

### How to integrate

1. Fake `TtsEngine` / `TrainingEngine` / `EmbeddingEngine` in tests.
2. One adapter test per local model you turn on (XTTS, Piper, Custom).
3. Keep weights and secrets out of git.

### What to fix in the mock

- There are no tests and no adapters yet.

### Get help

- Add-a-model steps: [AI-DEVELOPER.md](../AI-DEVELOPER.md)
- Must hold / Do not: same doc
- If tests need a running page: fullstack F1
