# Fullstack help — how to build each ticket

For engineers implementing [FULLSTACK-TICKETS.md](../FULLSTACK-TICKETS.md). Screenshots are the look. The mock is not the backend.

Read first: [ARCHITECTURE.md](ARCHITECTURE.md) and [GET-HELP.md](GET-HELP.md).

Handoff: you start the job and show status. AI/ML implements the engine. See [AI-ML-HELP.md](AI-ML-HELP.md).

---

## F1 — Stand up the studio apps, sign-in, and the character budget

### What done looks like

![Studio shell and dashboard](screenshots/shell-dashboard.png)

![Search palette](screenshots/search-palette.png)

Look at: sidebar, quota bar, Cmd+K, theme, notifications.

### Architecture

- Area: Workspace
- Lives in: `apps/web` shell, `apps/api` JWT + `/me` + `/quota`, `apps/worker` process, Redis, object storage
- Ports you own: `JobQueue`, `ObjectStorage` (plumbing). You do not own TTS.

### How to integrate

1. Create `apps/web`, `apps/api`, `apps/worker`, `packages/contracts`.
2. Sign-in issues a JWT. Web sends it on every call.
3. `GET /me` fills name, role, company. `GET /quota` fills the side-bar meter.
4. Block generate when the script would go over remaining characters (warn at 80%).
5. Worker claims jobs from Redis. Pages poll. No websockets.
6. All twelve routes open. Empty screens are fine until later tickets.

### What to fix in the mock

- There is no real sign-in. `#userEmail` is hardcoded from `MOCK.user`.
- Quota `1.24M / 2M` is static HTML in `index.html`.
- No `apps/*` yet. This folder is a static mock.

### Get help

- Product and API: [AUDIO-STUDIO.md](../AUDIO-STUDIO.md) (`/me`, `/quota`)
- Layers: [ARCHITECTURE.md](ARCHITECTURE.md)
- Queue exists but generate makes no audio: [AI-ML-HELP.md](AI-ML-HELP.md) M6

---

## F2 — Start a project and open it later

### What done looks like

![Projects grid](screenshots/projects.png)

![New project modal](screenshots/projects-new-modal.png)

![Open project drawer](screenshots/projects-open-drawer.png)

Look at: **Projects**

### Architecture

- Area: Catalog
- Lives in: `apps/web` Projects page, `apps/api` `GET, POST /projects`, `GET /projects/:id`
- Postgres: project row (name, client, language, clips, chars, status)

### How to integrate

1. List from `GET /projects`. Create from the modal via `POST /projects`.
2. Open drawer uses `GET /projects/:id` (clips, characters, status).
3. Generate button sets that project id on `#/generate`.
4. Keep status `Training` until the corpus job completes (F9 / M8).

### What to fix in the mock

- Cards come from `mock-data/projects.json`.
- Create only toasts “Project created (demo)”.
- Open drawer reads the mock object, not an API.

### Get help

- API: [AUDIO-STUDIO.md](../AUDIO-STUDIO.md) Projects
- Training status never clears: F9 and M8

---

## F3 — Add a speaker and show if the voice is ready

### What done looks like

![Voice Library](screenshots/voices.png)

Look at: **Voice Library**

### Architecture

- Area: Catalog
- Lives in: Voice page; `POST /voices`, `POST /voices/:id/reference` (multipart), `POST /voices/:id/reprocess`, `DELETE /voices/:id`, `GET /voices`
- Port you call (do not own): `EmbeddingEngine` (M1, M2)

### How to integrate

1. Create speaker (name, language) then upload `.wav` / `.mp3`.
2. Store the file in object storage. Enqueue process.
3. Poll status: Processing / Ready / Failed.
4. Play uses the file URL. Only Ready voices are offered on Generate.
5. Replace and delete hit the same APIs.

### What to fix in the mock

- Upload modal says “This control is visual only.”
- Create & Process appends a fake Processing card in memory.
- Reprocess only toasts.

### Get help

- API: [AUDIO-STUDIO.md](../AUDIO-STUDIO.md) Voices
- Status never becomes Ready: M1
- Failed cannot recover: M2

---

## F4 — List models and save their settings

### What done looks like

![Models](screenshots/models.png)

![Configure drawer](screenshots/models-configure.png)

Look at: **Models**

### Architecture

- Area: Catalog
- Lives in: Models page; `GET, PATCH /models`, `PATCH /models/:id/config`
- Port you call: `ModelRegistry` (M4, M5)

### How to integrate

1. Render External TTS, XTTS v2, Piper, Custom TTS from `GET /models`.
2. Show type, health, languages, endpoint, compute, latency.
3. Configure saves knobs. The same knobs appear on Generate → Advanced (F5 + M5).
4. Never change the model the person picked.

### What to fix in the mock

- Cards come from `mock-data/models.json`.
- Configure save is a toast only.

### Get help

- Health looks wrong: M4
- Knobs do not affect speech: M5
- Screen list: [AUDIO-STUDIO.md](../AUDIO-STUDIO.md) Models

---

## F5 — Start a generate job from a script

### What done looks like

![Generate empty](screenshots/generate-empty.png)

![Generate preview](screenshots/generate-preview.png)

Look at: **Generate Audio**

### Architecture

- Area: Generation
- Lives in: Generate page; `POST /jobs`, `POST /clips/:id/save`, `GET /clips/:id/audio`, `GET /jobs/:id`
- Port you call (do not own): `TtsEngine` (M6, M7, M9)

### How to integrate

1. Page collects script, project, voice, model, delivery, performance, voice match, advanced knobs.
2. API rejects empty script, over 5,000 characters, over-quota, or a voice that is not Ready.
3. Enqueue generate. Page polls `GET /jobs/:id`.
4. Preview plays `GET /clips/:id/audio`.
5. Save → Draft. Send to review → In review and open F8. Regenerate → new job.

### What to fix in the mock

- Generate is a 900ms `setTimeout` in `js/app.js`.
- Voices and projects come from `MOCK.*`.
- Preview is a fake waveform, not a file URL.

### Get help

- API: [AUDIO-STUDIO.md](../AUDIO-STUDIO.md) `POST /jobs`
- Job queues, no audio: M6, M7, or M9
- Quota wrong: F1

---

## F6 — Show where each job is

### What done looks like

![Generation Jobs](screenshots/jobs.png)

Look at: **Generation Jobs**

### Architecture

- Area: Generation
- Lives in: Jobs page; `GET /jobs`, `GET /jobs/:id`
- Worker writes stage and progress. You display it.

### How to integrate

1. Pipeline: Queued → Processing → Evaluating → Review → Approved (or Failed / Rejected).
2. Train jobs: Processing → Completed or Failed.
3. Poll the list. Show error text on failed rows.
4. Same counts feed F10 later.

### What to fix in the mock

- Rows are `mock-data/jobs.json`. They do not move.

### Get help

- Stages: [AUDIO-STUDIO.md](../AUDIO-STUDIO.md) and [AI-DEVELOPER.md](../AI-DEVELOPER.md)
- Job stuck in Processing: worker + M6 / M8

---

## F7 — Find a clip, play it, and download it

### What done looks like

![Generated Audio](screenshots/audio.png)

Look at: **Generated Audio**

### Architecture

- Area: Generation
- Lives in: clip table; `GET /clips`, `GET /clips/:id`, `GET /clips/:id/audio`

### How to integrate

1. Search script, id, project. Filter Approved / In review / Regenerate / Draft / Rejected. Filter by voice. Sort columns.
2. Play and export use the stored file URL.
3. Review icon opens F8 for that clip.
4. Empty filter shows “No clips match”.

### What to fix in the mock

- Rows are `mock-data/clips.json`.
- Play is a fake progress animation, not audio.
- Export toasts “Saved…”.

### Get help

- No clip after generate: F5 then M6
- File URL 404: object storage from F1

---

## F8 — Compare takes and record the decision

### What done looks like

![Review and Compare](screenshots/review.png)

Look at: **Review & Compare**

### Architecture

- Area: Quality
- Lives in: Review page; `GET /reviews/:clipId`, `POST .../approve`, `POST .../reject`, `POST .../regenerate`
- Port you call (do not own): `QualityEvaluator` (M10)

### How to integrate

1. Play reference and generated side by side. Show the script.
2. Show scores from M10 (do not invent them in the page).
3. Comment is stored on reject when provided.
4. Approve / Reject update the clip. Request regeneration starts F5 again.

### What to fix in the mock

- Always shows `MOCK.reviews[0]`.
- Scores are hardcoded.
- Buttons only toast.

### Get help

- Scores missing or fake: M10
- New take does not start: F5
- API: [AUDIO-STUDIO.md](../AUDIO-STUDIO.md) Reviews

---

## F9 — Start a train job from a dataset

### What done looks like

![Training Datasets](screenshots/datasets.png)

![Failed dataset drawer](screenshots/datasets-failed-drawer.png)

Look at: **Training Datasets**

### Architecture

- Area: Catalog
- Lives in: Datasets page; `GET, POST /datasets`, `GET /datasets/:id`, `POST /datasets/:id/train`
- Port you call (do not own): `TrainingEngine` (M8)

### How to integrate

1. Table: files, duration, quality, status, progress, model, updated.
2. Start train only on a local model. External TTS has no train.
3. Poll progress. Show a plain error in the drawer when Failed.
4. Project stays Training until the corpus completes.

### What to fix in the mock

- Table is `mock-data/datasets.json`.
- There is no Start train control — add the API call, keep the same table look.
- Drawer is read-only mock.

### Get help

- Train runs, no checkpoint: M8
- Dataset grouping rules: M3
- API: [AUDIO-STUDIO.md](../AUDIO-STUDIO.md) Datasets

---

## F10 — Show how the studio is doing today

### What done looks like

![Dashboard](screenshots/shell-dashboard.png)

Look at: **Dashboard**

### Architecture

- Area: Observability
- Lives in: Dashboard page; `GET /dashboard`

### How to integrate

1. KPIs from live projects, clips, quota, reviews, jobs.
2. Recent clips → F7. Activity → same events as F12. Job pillars → F6 counts.
3. Buttons go to Generate and Jobs.

### What to fix in the mock

- KPIs and activity are `mock-data/dashboard.json`.

### Get help

- Job counts disagree with F6: use one query
- API: `GET /dashboard`

---

## F11 — Show what we made over time

### What done looks like

![Analytics](screenshots/analytics.png)

Look at: **Analytics**

### Architecture

- Area: Observability
- Lives in: Analytics page; `GET /analytics`

### How to integrate

1. Volume over months, model mix, voice mix, approval, similarity, fail rate, median time.
2. Read stored generate and review rows. Do not hardcode the SVG numbers.

### What to fix in the mock

- Charts use `mock-data/analytics.json` and `js/waveform.js`.

### Get help

- Quality numbers: M10 + F8
- API: `GET /analytics`

---

## F12 — Show who did what

### What done looks like

![Audit Logs](screenshots/audit.png)

Look at: **Audit Logs**

### Architecture

- Area: Observability
- Lives in: Audit page; `GET /audit`
- Write a row from the API when the action happens (do not wait for this page to load).

### How to integrate

1. Columns: user, action, project, clip/job, time, status.
2. Log sample upload, train start, train fail, model config change, generate, approve, reject.

### What to fix in the mock

- Table is `mock-data/audit.json`. Nothing writes new rows.

### Get help

- What to log: [AI-DEVELOPER.md](../AI-DEVELOPER.md) Jobs, review, audit
- API: `GET /audit`

---

## F13 — Update profile and studio defaults

### What done looks like

![Settings profile](screenshots/settings-profile.png)

![Settings notifications](screenshots/settings-notify.png)

Look at: **Settings** (Profile, Preferences, Notifications, API, Model)

### Architecture

- Area: Workspace
- Lives in: Settings page; `PATCH /settings`, `GET /me`, model defaults via `PATCH /models`

### How to integrate

1. Save name, email, theme, timezone, default model.
2. Alerts: job done, review assigned, training failed, quota warnings.
3. Admin rotates the workspace key. Store the secret outside git.
4. Model defaults: region, max concurrency.

### What to fix in the mock

- Values come from `mock-data/settings.json`.
- Save only toasts “this browser session”.
- API key is a placeholder string.

### Get help

- API: [AUDIO-STUDIO.md](../AUDIO-STUDIO.md) `/me`, `/settings`
- Secrets: [AI-DEVELOPER.md](../AI-DEVELOPER.md) Must hold
