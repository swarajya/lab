# Engineering help — one file per ticket

Assign a ticket and open **only that file**. Do not wait for a meeting or a Slack thread.

| If you need | Open |
| --- | --- |
| How the system is split | [../ARCHITECTURE.md](../ARCHITECTURE.md) |
| Symptom → which ticket file | [../GET-HELP.md](../GET-HELP.md) |
| Product rules and API list | [../../AUDIO-STUDIO.md](../../AUDIO-STUDIO.md) |
| Voice loop and ports | [../../AI-DEVELOPER.md](../../AI-DEVELOPER.md) |
| Screen look | `index.html` hashes, or [../screenshots/](../screenshots/) |

## Fullstack

| Ticket | File |
| --- | --- |
| F1 Stand up apps, sign-in, quota | [F1.md](F1.md) |
| F2 Projects | [F2.md](F2.md) |
| F3 Voice Library page | [F3.md](F3.md) |
| F4 Models page | [F4.md](F4.md) |
| F5 Generate job | [F5.md](F5.md) |
| F6 Jobs page | [F6.md](F6.md) |
| F7 Generated Audio | [F7.md](F7.md) |
| F8 Review decisions | [F8.md](F8.md) |
| F9 Start train | [F9.md](F9.md) |
| F10 Dashboard | [F10.md](F10.md) |
| F11 Analytics | [F11.md](F11.md) |
| F12 Audit | [F12.md](F12.md) |
| F13 Settings | [F13.md](F13.md) |

## AI/ML

| Ticket | File |
| --- | --- |
| M1 Ready voice | [M1.md](M1.md) |
| M2 Reprocess | [M2.md](M2.md) |
| M3 Dataset | [M3.md](M3.md) |
| M4 Model health | [M4.md](M4.md) |
| M5 Knobs | [M5.md](M5.md) |
| M6 Stock local speak | [M6.md](M6.md) |
| M7 External TTS | [M7.md](M7.md) |
| M8 Train | [M8.md](M8.md) |
| M9 Checkpoint speak | [M9.md](M9.md) |
| M10 Score and compare | [M10.md](M10.md) |
| M11 Adapter tests | [M11.md](M11.md) |

Every file has the same sections: visual contract, done when, you own, layout, APIs, integrate, replace in mock, edge cases, tests, depends on, if blocked, must not.
