# Where to get help

Do not message a person for ticket scope. Open the ticket file.

**Index:** [tickets/README.md](tickets/README.md)

## Docs

| Need | Open |
| --- | --- |
| How to implement one ticket | [tickets/README.md](tickets/README.md) then that ticket’s `.md` |
| System split | [ARCHITECTURE.md](ARCHITECTURE.md) |
| Product rules, screen list, API list | [AUDIO-STUDIO.md](../AUDIO-STUDIO.md) |
| Voice loop, ports, add-a-model | [AI-DEVELOPER.md](../AI-DEVELOPER.md) |
| Ticket titles only | [FULLSTACK-TICKETS.md](../FULLSTACK-TICKETS.md), [AI-ML-TICKETS.md](../AI-ML-TICKETS.md) |
| Screen look | Mock `index.html` `#/…` or [screenshots/](screenshots/) |

## Symptom → ticket file

| Symptom | File |
| --- | --- |
| Cannot sign in, quota, or queue | [tickets/F1.md](tickets/F1.md) |
| Project list or create | [tickets/F2.md](tickets/F2.md) |
| Upload / voice status on the page | [tickets/F3.md](tickets/F3.md) |
| Encode never Ready | [tickets/M1.md](tickets/M1.md) |
| Failed voice cannot recover | [tickets/M2.md](tickets/M2.md) |
| Model cards or saved knobs | [tickets/F4.md](tickets/F4.md) |
| Health wrong or engine swaps | [tickets/M4.md](tickets/M4.md) |
| Generate button / job never queues | [tickets/F5.md](tickets/F5.md) |
| Job queues, no audio | [tickets/M6.md](tickets/M6.md), [M7.md](tickets/M7.md), [M9.md](tickets/M9.md) |
| Job list stale | [tickets/F6.md](tickets/F6.md) |
| Clip list / play / download | [tickets/F7.md](tickets/F7.md) |
| Review buttons | [tickets/F8.md](tickets/F8.md) |
| Scores missing | [tickets/M10.md](tickets/M10.md) |
| Train button | [tickets/F9.md](tickets/F9.md) |
| No checkpoint / no train error | [tickets/M8.md](tickets/M8.md) |
| Dashboard / analytics / audit | [tickets/F10.md](tickets/F10.md), [F11.md](tickets/F11.md), [F12.md](tickets/F12.md) |
| Settings | [tickets/F13.md](tickets/F13.md) |
| Tests need weights | [tickets/M11.md](tickets/M11.md) |

## Still unclear after the ticket file

Re-read **If blocked** in that file. It only points at another file. If two files disagree, [AUDIO-STUDIO.md](../AUDIO-STUDIO.md) wins for product; [AI-DEVELOPER.md](../AI-DEVELOPER.md) wins for ports.
