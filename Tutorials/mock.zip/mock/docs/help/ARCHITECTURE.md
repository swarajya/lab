# Architecture — Audio Studio

One picture for fullstack and AI/ML. Product rules: [AUDIO-STUDIO.md](../AUDIO-STUDIO.md). Voice loop and ports: [AI-DEVELOPER.md](../AI-DEVELOPER.md).

## Apps

```
apps/web     React UI (replace this mock)
apps/api     Node.js / Fastify HTTP
apps/worker  Generate and train jobs
packages/contracts  Shared types
```

| Piece | Role |
| --- | --- |
| Web | Screens. Talks only to the API. Polls jobs. No websockets. |
| API | JWT, quota, save/load. Enqueues generate and train. Does not run TTS. |
| Worker | Claims a job. Calls an AI/ML port. Writes files and status. |
| Postgres | Projects, voices, jobs, clips, reviews, logs |
| Redis | Job queue |
| Files | Samples, clips, checkpoints |
| Auth | JWT |

Domain does not import Fastify, Prisma, Redis, React, or a TTS library. New vendor = new adapter on the same port.

## Areas

| Area | Owns | Tickets |
| --- | --- | --- |
| Workspace | User, settings, quota | F1, F13 |
| Catalog | Project, voice, dataset, model | F2, F3, F4, F9, M1–M5, M8 |
| Generation | Generate job, clip | F5, F6, F7, M6, M7, M9 |
| Quality | Review, scores | F8, M10 |
| Observability | Audit, dashboard, analytics | F10, F11, F12 |

## AI/ML ports

| Port | Does | Ticket |
| --- | --- | --- |
| `SampleStore` | Save reference takes | M1 |
| `EmbeddingEngine` | Sample → embedding | M1, M2 |
| `TrainingEngine` | Dataset + base model → checkpoint | M8 |
| `TtsEngine` | Script + voice + model → audio | M6, M7, M9 |
| `QualityEvaluator` | Reference + clip → scores | M10 |
| `ModelRegistry` | List, health, endpoint, config | M4, M5 |
| `JobQueue` | Enqueue generate or train | F1 |
| `ObjectStorage` | Audio and checkpoints | F1, M1, M8 |

Worker, generate: claim → `TtsEngine` → `QualityEvaluator` → save clip.

Worker, train: claim → `TrainingEngine` → write checkpoint → model Healthy or Failed.

## How the two teams meet

```mermaid
flowchart LR
  web[apps_web] --> api[apps_api]
  api --> pg[Postgres]
  api --> redis[Redis_queue]
  api --> files[ObjectStorage]
  worker[apps_worker] --> redis
  worker --> files
  worker --> tts[TtsEngine]
  worker --> train[TrainingEngine]
  worker --> embed[EmbeddingEngine]
  worker --> quality[QualityEvaluator]
  api --> registry[ModelRegistry]
```

**Handoff:** fullstack starts the job and shows status. AI/ML implements the engine the worker calls.

| Fullstack | AI/ML |
| --- | --- |
| Page, API, queue, files, quota | Encode, train, speak, score |
| F5 starts `POST /jobs` | M6 / M7 / M9 make the audio |
| F9 starts `POST /datasets/:id/train` | M8 writes the checkpoint |
| F8 shows scores and buttons | M10 computes the scores |
| F3 shows Processing / Ready / Failed | M1 / M2 build or fix the embedding |

## API map

See [AUDIO-STUDIO.md](../AUDIO-STUDIO.md) for the full list. Upload is multipart. Playback is a file URL.

## Must hold

- Sample → embedding → Ready before generate
- Failed voice can reprocess
- Train writes a checkpoint or a clear error
- The model the person picked is the model that runs
- Quota counts characters
- No model weights or secrets in git
- Tests use fake ports
