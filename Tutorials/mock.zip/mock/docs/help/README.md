# Builder help

Assign a ticket and open **[tickets/README.md](tickets/README.md)**. Each ticket is its own engineering file. No walkthrough required.

| File | Use |
| --- | --- |
| [tickets/README.md](tickets/README.md) | One file per ticket (start here) |
| [ARCHITECTURE.md](ARCHITECTURE.md) | Apps, areas, ports, handoff |
| [GET-HELP.md](GET-HELP.md) | Symptom → ticket file |
| [FULLSTACK-HELP.md](FULLSTACK-HELP.md) | Short overview of F1–F13 |
| [AI-ML-HELP.md](AI-ML-HELP.md) | Short overview of M1–M11 |
| [screenshots/](screenshots/) | Mock captures |

**In the browser:** serve the repo root, then open [view.html](view.html).

```bash
cd mock
python3 -m http.server 4173
```

Then http://127.0.0.1:4173/docs/help/view.html

Opening a `.md` file directly (double-click or `file://`) shows raw text. Cursor and GitHub also render Markdown in their own previews.

Tickets: [../AUDIO-STUDIO-TICKETS.md](../AUDIO-STUDIO-TICKETS.md)

To recapture screenshots: serve the repo root, then run `capture-screenshots.mjs` with Playwright and Chrome (`channel: "chrome"`).
