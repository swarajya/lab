import { mkdir } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

const root = join(dirname(fileURLToPath(import.meta.url)), "../..");
const out = join(root, "docs/help/screenshots");
const base = process.env.HELP_BASE || "http://127.0.0.1:4173";

await mkdir(out, { recursive: true });

const browser = await chromium.launch({ channel: "chrome", headless: true });
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });

async function shot(name) {
  await page.waitForTimeout(400);
  await page.screenshot({ path: join(out, name), fullPage: true });
  console.log("wrote", name);
}

async function go(hash, search = "") {
  const url = search ? `${base}/${search}${hash}` : `${base}/${hash}`;
  await page.goto(url, { waitUntil: "domcontentloaded" });
  await page.waitForSelector("#view");
  await page.waitForTimeout(400);
}

await go("#/dashboard");
await shot("shell-dashboard.png");

await page.click("#globalSearch");
await page.waitForSelector("#paletteInput");
await shot("search-palette.png");
await page.keyboard.press("Escape");

await go("#/projects");
await shot("projects.png");
await page.click('[data-action="new-project"]');
await page.waitForSelector("#modal:not([hidden])");
await shot("projects-new-modal.png");
await page.keyboard.press("Escape");
await page.click('[data-action="open-project"]');
await page.waitForSelector("#drawer:not([hidden])");
await shot("projects-open-drawer.png");
await page.keyboard.press("Escape");

await go("#/voices");
await shot("voices.png");
await page.locator(".spk-card").filter({ hasText: "Failed" }).first().screenshot({ path: join(out, "voices-failed.png") });
console.log("wrote voices-failed.png");

await go("#/datasets");
await shot("datasets.png");
await page.click('[data-action="open-dataset"][data-id="ds-hindi"]');
await page.waitForSelector("#drawer:not([hidden])");
await shot("datasets-failed-drawer.png");
await page.keyboard.press("Escape");

await go("#/models");
await shot("models.png");
await page.click('[data-action="open-model"]');
await page.waitForSelector("#drawer:not([hidden])");
await shot("models-configure.png");
await page.keyboard.press("Escape");

await go("#/generate");
await shot("generate-empty.png");

await go("#/generate", "?ready");
await shot("generate-preview.png");

await go("#/generate");
await page.selectOption("#selModel", { label: "XTTS v2" });
await page.waitForTimeout(200);
await page.evaluate(() => {
  const d = document.querySelector("#advParams");
  if (d) d.open = true;
});
await shot("generate-xtts-advanced.png");

await page.selectOption("#selModel", { label: "External TTS" });
await page.waitForTimeout(200);
await page.evaluate(() => {
  const d = document.querySelector("#advParams");
  if (d) d.open = true;
});
await shot("generate-external-advanced.png");

await page.selectOption("#selModel", { label: "Custom TTS" });
await page.waitForTimeout(200);
await page.evaluate(() => {
  const d = document.querySelector("#advParams");
  if (d) d.open = true;
});
await shot("generate-custom-checkpoint.png");

await go("#/jobs");
await shot("jobs.png");

await go("#/audio");
await shot("audio.png");

await go("#/review");
await shot("review.png");

await go("#/analytics");
await shot("analytics.png");

await go("#/audit");
await shot("audit.png");

await go("#/settings");
await shot("settings-profile.png");
await page.click('[data-settings="notify"]');
await page.waitForTimeout(200);
await shot("settings-notify.png");

await browser.close();
