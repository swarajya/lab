# Audio Studio — Project requirements

AI voice production workspace. Engineers and AI developers take voice samples, train or fine-tune models, and generate speech from a script. Reviewers compare the take to a reference and approve, reject, or ask for a new one.

AI workflow: [AI-DEVELOPER.md](AI-DEVELOPER.md).

## Users

| Role | Does |
|---|---|
| Audio engineer | Owns projects, scripts, clips, and review |
| AI developer | Samples, datasets, train / fine-tune, local and remote models |
| Reviewer | Scores and decides approve / reject / regenerate |
| Admin | Settings, quota, API keys, model defaults |

## Words we use

| Word | Meaning |
|---|---|
| Project | A client job (narration pack, support voice, product demo). |
| Voice | A speaker plus reference sample and embedding. |
| Sample | A reference recording for a voice. |
| Dataset | Samples used to train or fine-tune a model. |
| Model | A TTS engine. Local: XTTS, Piper, Custom. Remote: External TTS. |
| Fine-tune | Train a local model on a dataset, then generate with that checkpoint. |
| Job | One generate or train run. It moves through stages. |
| Clip | The audio file a generate job produces. |
| Review | Side-by-side listen: reference vs generated, plus scores. |
| Quota | Character budget for the org. |

## What the product must do

1. Create projects and track clips, characters, language, and status.
2. Create voices, upload samples, build embeddings, reprocess, delete.
3. Group samples into datasets and train or fine-tune a target model.
4. Run local models (XTTS, Piper, Custom) and optional External TTS.
5. Generate audio from a script (max 5,000 characters) with voice, model, and knobs.
6. Move generate jobs: Queued → Processing → Evaluating → Review → Approved, or Failed / Rejected.
7. Review reference vs generated; score; approve, reject, or regenerate.
8. Show dashboard KPIs, analytics, and an audit log.
9. Enforce character quota.

Save without review leaves a clip as Draft. Regenerate starts a new generate job.

## Screens

| Screen | Must show |
|---|---|
| Dashboard | KPIs, recent clips, activity, job counts |
| Projects | List, create, open; jump to generate or audio |
| Generate Audio | Script, project, voice, model, delivery, performance, voice match, advanced knobs, preview, save, send to review |
| Voice Library | New speaker, upload sample, play, replace, reprocess, use in generate, delete |
| Training Datasets | Files, duration, quality, target model, status, progress, error |
| Generated Audio | Search, filter by status and voice, sort, play, export, open review |
| Review & Compare | Reference vs generated, scores, comment, approve / reject / regenerate |
| Generation Jobs | Pipeline and job table (status, progress, model, voice, time, error) |
| Models | Type, health, endpoint, compute, config |
| Analytics | Volume, model mix, voice mix, quality |
| Audit Logs | User, action, project, target, time, status |
| Settings | Profile, preferences, notifications, API key, model defaults |

## API

| Method | Path | For |
|---|---|---|
| GET | `/me` | Current user |
| PATCH | `/settings` | Save settings |
| GET | `/quota` | Character quota |
| GET, POST | `/projects` | List / create |
| GET | `/projects/:id` | Open project |
| GET, POST | `/voices` | List / create speaker |
| POST | `/voices/:id/reference` | Upload or replace sample |
| POST | `/voices/:id/reprocess` | Rebuild embedding |
| DELETE | `/voices/:id` | Remove voice |
| GET, POST | `/datasets` | List / create |
| GET | `/datasets/:id` | Dataset detail |
| POST | `/datasets/:id/train` | Start train / fine-tune |
| POST | `/jobs` | Start generate |
| GET | `/jobs` | Job list |
| GET | `/jobs/:id` | Job status |
| GET | `/clips` | Clip list |
| GET | `/clips/:id` | Clip detail |
| POST | `/clips/:id/save` | Keep as draft |
| GET | `/clips/:id/audio` | Play or export |
| GET | `/reviews/:clipId` | Review |
| POST | `/reviews/:clipId/approve` | Approve |
| POST | `/reviews/:clipId/reject` | Reject |
| POST | `/reviews/:clipId/regenerate` | New job |
| GET, PATCH | `/models` | List / defaults |
| PATCH | `/models/:id/config` | Model knobs |
| GET | `/dashboard` | Home KPIs |
| GET | `/analytics` | Charts |
| GET | `/audit` | Logs |

Audio upload is multipart. Playback is a file URL.

## System

- **Web** — React
- **API** — Node.js / Fastify
- **Worker** — generate and train jobs
- **Postgres** — projects, voices, jobs, clips, reviews, logs
- **Redis** — job queue
- **Files** — samples, clips, checkpoints
- **Models** — local train + infer; External TTS if selected
- **Auth** — JWT

Domain does not import Fastify, Prisma, Redis, or React.

```
apps/web     React UI
apps/api     HTTP API
apps/worker  Job runner
packages/contracts  Shared types
```

Each API area: `domain` / `application` (ports) / `infrastructure` / `interface/http`.

| Area | Owns |
|---|---|
| Workspace | User, settings, quota |
| Catalog | Project, voice, dataset, model |
| Generation | Generate job, clip |
| Quality | Review, scores |
| Observability | Audit, dashboard |

## Out of scope

- Billing beyond the quota meter
- Redesign of the existing screens
- Live websockets (poll jobs)
